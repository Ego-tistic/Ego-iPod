# Ego-iPod publication preparation

The existing repository source was found at Ego-tistic/Pro-Pods-Repo. Its Pro-Pods 1.0.2~diagnostic2 package is preserved byte for byte. Mac-Launcher 1.0.0 is added alongside it, with open-source archive and MIT license. The requested new repository name/Pages address are Ego-iPod and https://ego-tistic.github.io/Ego-iPod/. This is a GitHub repository rename, not only a display label change. Old project Pages URLs should not be relied upon to redirect. Publication state must be checked on GitHub/the actual hosted files; local preparation alone is not a live deployment.

# Mac-Launcher 1.0.0 release build

Surface Opacity now snaps to 0%, 5%, 10%, …, 100% during dragging, displays the selected percentage, and persists on release. VoiceOver increment/decrement also moves exactly 5%. Older stored values are rounded when read; new writes are clamped and quantized centrally. A dedicated Preferences cell keeps the displayed thumb/value consistent. The default is 35%. Native C tests cover all step boundaries, midpoint rounding, invalid numbers, clamping and 3,001 sampled inputs; host binary/signature and repo tests passed. The updated Settings control still needs device interaction testing.

The requested repository display name is Ego-iPod. Do not rename a GitHub user-site repository or replace an existing full Packages index without reviewing its actual source. The provided https://ego-tistic.github.io returned HTTP 404 during this session; the inferred public source repository was inaccessible too. A separate Ego-iPod-staging folder is a local single-package preparation only; it has not been merged into the existing ProPods repo, published or pushed. Its Release Origin/Label are Ego-iPod. Existing package preservation, hosting configuration, signing and final publication require the actual source repo.

# Mac-Launcher 0.5.0

The product is now named Mac-Launcher in Settings, Activator and package metadata, with a custom Mac-style computer Settings icon at 1x/2x/3x. The internal package ID/domain and bundle names stay the same so this upgrades the existing install and preserves selections and assignments.

The dock starts with a separate, unlabeled recent-app section (up to five unique apps, newest first), followed by a divider and remaining chosen apps without duplicates. The drawer/search continues to use its original selected-app catalog and alphabetical ordering. Launcher-hidden and uninstalled apps are not displayed in recents. No placeholder/random apps fill an empty history; the five slots fill as you use apps after installation. History stores five IDs locally and persists across resprings. Existing system usage history is not imported.

Recency is recorded from the guarded private SpringBoard frontDisplayDidChange: callback, not from speculative launcher taps, so foreground changes from outside the launcher can count too. On opening the launcher a guarded _accessibilityFrontMostApplication query seeds the current app. These private callbacks/selectors require testing on the actual iOS 12.5.8 device. If unavailable, complete tracking is not guaranteed. No Home-button interception was added. Source reference for the callback shape: https://github.com/DGh0st/DVirtualHome/blob/master/Tweak.xm . The new code is an independent implementation.

Device checks: open six different allowed apps from Home Screen and from this launcher, verify newest-first eviction/deduplication, respring persistence, hide/uninstall a recent app, hold a recent icon, tap the divider (must not launch), search from the dock and check that the drawer order is unchanged. Existing light/dark, opacity, magnification, accessibility, lock safety and launch-close checks still apply. Host build/signature checks do not prove runtime recency tracking.

## Version 0.4.0: theme and transparency controls

Settings → Orbit Launcher now includes a Dark Theme switch (on = dark, off = light) and a Surface Opacity slider (0–100, default 35). The slider changes glass panel opacity, borders/highlights, search-button fill and backdrop strength, without fading app icons or text. Dock background blur remains independently disabled unless enabled by its existing switch. The theme also changes the drawer blur style, search-bar appearance, icons' text labels, search glyph, close control, empty state and long-press tooltip. Changes apply on reopening the launcher, without a respring. Reopen Settings after upgrading to load the new preference bundle.

Reduce Transparency overrides the slider with solid surfaces for readability. At zero opacity, surface decoration/backdrop fade away; this is not a blur-radius control. Verify dark/light × opacity 0/35/100 in the drawer and dock, with dock blur enabled/disabled, long-press labels, search/keyboard, and Reduce Transparency on the actual device. Host package checks do not prove visual contrast or slider interaction on the device.


## Version 0.4.0: glass and icon quality

Both layouts now use lightweight translucent gradient surfaces, specular rims and shadows. This is a glass-inspired iOS 12 implementation, not Apple's native iOS 26 Liquid Glass renderer or optical refraction. The dock still has no backdrop blur unless Blur Behind Dock is enabled. Reduce Transparency uses an opaque backing; Reduce Motion retains the previous nonmoving fallback.

Icon loading requests format 2 at scale 3 or higher and checks returned CGImage pixels against the magnified 72pt icon. Format 0 is retained only as a fallback if it returns more pixels. No small image is redrawn/upscaled into a fake high-resolution asset; system icon masking is preserved instead of clipping it again. Actual returned pixel sizes and parity with themed Home Screen icons need device checking. Format 0's small-icon use can be seen in the upstream [AppList implementation](https://github.com/rpetrich/AppList/blob/master/ALApplicationList.x). No AppList runtime dependency was added.

Hold an app for 0.35 seconds to show its name above the icon (or below if it is at the top). Move across icons while holding to change the name. Release to dismiss the name; holding does not launch. Tap normally to launch. The tooltip is outside the scrolling surface so it is not clipped by the dock. Check hold versus drag/tap interaction, long names, top-row icons, keyboard visibility, VoiceOver, scrolling and first/last dock items on the device.

Compilation/package/signature checks are host checks only. Native Liquid Glass, actual icon pixel output, visual polish/performance on A8 and the new long-press behavior have not been verified on an iPod in this environment.

# Orbit Launcher 0.4.0

MIT-licensed source implementation of a Vesta-inspired launcher for **rootful iOS 12, arm64**. Designed for the iPod touch 6th generation. Independent implementation; no Vesta code or assets are included.

**Delivery status:** a real `io.github.orbitlauncher_0.4.0_iphoneos-arm.deb` was compiled and signed on November 4, 2026 using Theos in Ubuntu/WSL, the iOS 12.4 SDK and deployment target 12.0. Both arm64 binaries, their signed code-page hashes, package metadata, paths, ownership and permissions passed inspection. Version 0.4.0 has been rebuilt and package-checked, but its new animations and launch timing need a device check. The `.deb` is supplied separately from this source archive. **It has not been installed or tested on an actual iPod.** Amethyst injection/bootstrap compatibility and the device checks in [VALIDATION.md](VALIDATION.md) remain pending. Treat this as a first device-test build.

## What is implemented

- Searchable app drawer, switchable between grid and list.
- Mac-style horizontal dock with continuous inertial scrolling and center magnification. A fixed magnifying-glass button on the LEFT opens searchable drawer results. No pages or page controls.
- Drawer rises from the bottom over a dark blurred background. Dock springs into view above a rounded translucent shelf; full-screen dock blur is OFF by default and can be enabled with Blur Behind Dock. No launcher title.
- Settings preference bundle with searchable per-app switches and Show All / Hide All.
- Activator listener for Home triple-press, restricted to unlocked Home Screen and application modes.
- Close button, backdrop dismissal, Home deactivation callback, VoiceOver escape, lock/display-off dismissal, immediate overlay removal on app selection.

App selection is a **launcher-local exclusion list**, saved to `io.github.orbitlauncher` using CFPreferences under the mobile user. Initially all catalog apps are shown; newly installed apps are shown by default. To choose only a few, tap Hide All Apps and switch those apps on. Neither the tweak nor its preferences writes SpringBoard icon state, uninstalls apps, or changes iOS app visibility. Uninstalled app IDs can remain in the exclusions so reinstalling an excluded app keeps it excluded.

The catalog includes named User/System LaunchServices apps except entries tagged `hidden` and SpringBoard itself. It is not a list of background daemons or app extensions. Private LaunchServices metadata is not a guarantee that every catalog item is launchable; the LaunchServices BOOL is not treated as foreground confirmation. Launch requests run off the main UI thread after the overlay closes. A NO result is logged, without a misleading failure popup. Actual foreground success cannot be determined from that BOOL. Refresh the picker after app installations. The launcher rereads the catalog whenever opened.

## Home triple-press and conflicts

**Activator is required, not optional.** It is the only physical-button recognizer in this implementation; there is no second raw Home hook to compete with it. Activator declares a Home triple-press event in its [official API headers](https://github.com/rpetrich/libactivator/blob/headers/LAEvent.h). This avoids guessing iOS 12.5.8 internal Home-button recognizer behavior. It also means a working iOS 12 Activator installation is necessary on your jailbreak.

1. Install a trusted, iOS 12-compatible Activator build and PreferenceLoader. Verify Activator works independently on Amethyst first. The package manager must also have a compatible `mobilesubstrate` provider. Do not force dependency installation if the bootstrap differs.
2. Check **Settings → General → Accessibility → Accessibility Shortcut**. If you do not rely on it, uncheck every option to free Home triple-click. If you need that shortcut, keep it and assign Orbit a different Activator gesture instead. This project does not change Accessibility settings or suppress accessibility features.
3. After installing Orbit and respringing, open **Settings → Activator → At Home Screen → Home Button → Triple Press** and select **Orbit Launcher** (under Launchers).
4. Repeat under **In Application**. Labels can vary with Activator version/localization. Do not create a lock-screen assignment.
5. Remove any other action assigned to that gesture in those modes yourself. Check Anywhere assignments, profiles, and other tweaks that intercept Home as well.
6. Triple-press the **physical** Home button quickly while unlocked. A second triple-press toggles closed. Single/double presses are handled by iOS/Activator; Orbit does not swallow them directly.

Orbit never creates, replaces, or removes Activator assignments. The listener rejects presentation when disabled or locked, marks only accepted events handled, and does not offer an unlocking handler. Existing Accessibility/Activator conflicts cannot be conclusively detected from Orbit; there is no claim of automatic conflict detection. If app-switcher flashes or triple-press is not recognized, test the same gesture with another Activator action. Do not work around it by enabling a second Home-hook tweak. Recognition speed and behavior must be tested on the actual iPod.

## Build a real `.deb`

Use an existing **Theos** installation on macOS with full Xcode, Linux, Windows with WSL, or an appropriately configured jailbroken device. The official [installation overview](https://theos.dev/docs/installation), [macOS guide](https://theos.dev/docs/installation-macos), and [Linux/Windows guide](https://theos.dev/docs/installation-linux) describe setup. Build as a normal user. This project does not install a system toolchain for you.

Requirements:

- Theos with recursive vendor submodules, its Logos processor, arm64 iOS compiler/linker, ldid/signing support and GNU make.
- An iPhoneOS SDK capable of building for deployment target **12.0**. A legally obtained 12.x SDK allows the strictest availability check. A newer SDK can be used with deployment target 12.0, but must still be able to target that OS. Install SDKs under `$THEOS/sdks` as described by Theos.
- Theos Preferences headers/stub and Activator headers plus rootful `libactivator.tbd`. Current Theos vendor repositories contain them. These are build stubs, not a runtime Activator installation.

From this source directory in a POSIX shell:

```sh
export THEOS=/absolute/path/to/theos
sh tools/build.sh
```

The makefiles specify `ARCHS=arm64`, `TARGET=iphone:clang:latest:12.0`, ARC, SpringBoard-only injection, and `/Library/PreferenceBundles`. The build script forces the **default rootful scheme**. A nonempty package scheme is rejected by the root Makefile. To select an installed SDK explicitly:

```sh
sh tools/build.sh TARGET=iphone:clang:12.4:12.0
```

Both SDK and compiler must be installed; the command does not download them. For a direct build without the script:

```sh
chmod 755 layout/DEBIAN/postinst layout/DEBIAN/postrm
chmod 755 layout/DEBIAN
make clean THEOS_PACKAGE_SCHEME=
make package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME=
```

The result will be in `packages/`, normally `io.github.orbitlauncher_0.4.0_iphoneos-arm.deb`. The **Debian architecture is `iphoneos-arm` even though the Mach-O code is arm64**. This is the rootful package convention documented by [Theos packaging](https://theos.dev/docs/packaging). The package restricts firmware to `>=12.0` and `<13.0`; it is not a rootless or arm64e package.

The placeholder maintainer/package ID are usable for local testing. Before first public release, set your maintainer and author in `control`, and optionally choose a unique reverse-domain Package ID. If changing the namespace, update `io.github.orbitlauncher` consistently in `control`, Shared.m, preference Info.plist, and the PreferenceLoader/notification integrations as needed. Do not change the Package ID after release. Bump Version for every published update.

## Inspect, install, and remove

On the build machine, inspect the real package before transferring it:

```sh
dpkg-deb --info packages/your-built-package.deb
dpkg-deb --contents packages/your-built-package.deb
dpkg-deb --extract packages/your-built-package.deb /tmp/orbit-inspect
```

Replace the filename with the actual output. Confirm it contains `/Library/MobileSubstrate/DynamicLibraries/OrbitLauncher.dylib` and its filter, `/Library/PreferenceBundles/OrbitPrefs.bundle`, and the PreferenceLoader plist. Confirm **no `/var/jb` payload**. On macOS use `lipo -info`, `otool -l`, and `otool -L` on both Mach-O files to verify arm64, minimum iOS version 12.0, and library paths. Verify the binaries are ad-hoc signed by Theos/ldid.

The included package verifier checks the actual package and all code-page hashes, without an Apple signing certificate or a physical device:

```sh
python3 tools/verify_deb.py packages/your-built-package.deb
```

It requires Python 3.9+ and `dpkg-deb`, and is specific to this 0.4.0 arm64/iOS-12.4-SDK build. It does not replace device testing. The build script normalizes copied resource/control permissions and both makefiles explicitly request ad-hoc signing (`-S -Cadhoc`).

Transfer the built `.deb` to your iPod using your usual trusted file-transfer method. Install through a package manager that resolves dependencies, or, from an already authenticated root shell on the device:

```sh
dpkg -i /var/mobile/your-built-package.deb
```

`dpkg -i` does not fetch dependencies. Resolve them through Cydia/Zebra first; do not force the install. Installation and removal scripts respring via `sbreload` when available, falling back to `killall SpringBoard`. Save any active work first. Reopen Settings if its preference bundle was already loaded during an upgrade; UIKit does not unload an old bundle inside a running Settings process.

Configure **Settings → Orbit Launcher** and then make the Activator assignments above. Changes apply next time the launcher opens; changing preferences closes an open launcher. No respring is needed for style/app selections.

Remove normally in Cydia/Zebra, or run `dpkg -r io.github.orbitlauncher` in a root shell. Preferences remain by design. If troubleshooting an injection crash, boot into your jailbreak's documented safe/no-tweak mode, remove this package, and then resume injection. Do not modify SpringBoard's icon-layout files. Recovery specifics for Amethyst must come from its actual documentation; they have not been assumed here.

## Publish on your Cydia/Zebra repo

See [REPO.md](REPO.md) for a flat APT repository with generated Packages/Release files, compression, hashes, optional signatures, and existing-repo integration. The included `repo/` is an **empty scaffold**, not an installable release. Never publish it over an existing repo index. Nothing has been uploaded or pushed, and no repo URL is required until you choose to publish.

## Validation and limitations

[VALIDATION.md](VALIDATION.md) records the API audit, the exact host checks, and the required device acceptance tests. Public UI code uses iOS 12-era UIKit; app enumeration/icons/launching and the lock check use guarded private APIs. Missing lock APIs fail closed. The runtime headers audited are an iOS 12.0 snapshot, **not a dump from iOS 12.5.8**. Neither source review nor compiling proves runtime compatibility with Amethyst.

Run the host-side repository tests with Python 3.9 or newer:

```sh
python3 -m unittest discover -s tests -v
```

No test here simulates SpringBoard or proves app launching, blur compositing, lock safety, or physical Home behavior.
