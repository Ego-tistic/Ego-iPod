#import "Launcher.h"
#import "Shared.h"
#import <notify.h>
#import <math.h>
#import <QuartzCore/QuartzCore.h>

@interface SBLockScreenManager : NSObject
+ (instancetype)sharedInstance;
- (BOOL)isUILocked;
@end

static UIWindow *OLWindow;
static __weak UIWindow *OLPreviousWindow;
static BOOL OLObserversInstalled;

BOOL OLCanPresent(void) {
    if (![OLSettings()[@"enabled"] boolValue]) return NO;
    Class cls = NSClassFromString(@"SBLockScreenManager");
    if (![cls respondsToSelector:@selector(sharedInstance)]) return NO;
    id manager = [cls sharedInstance];
    if (![manager respondsToSelector:@selector(isUILocked)] || [manager isUILocked]) return NO;
    return YES;
}

void OLDismiss(void) {
    NSCAssert([NSThread isMainThread], @"UI must run on main thread");
    if (!OLWindow) return;
    [OLWindow endEditing:YES];
    OLWindow.hidden = YES;
    OLWindow.rootViewController = nil;
    OLWindow = nil;
    if (!OLPreviousWindow.hidden) [OLPreviousWindow makeKeyWindow];
    OLPreviousWindow = nil;
}

@interface OLCell : UICollectionViewCell
@property(nonatomic,strong) UIImageView *icon;
@property(nonatomic,strong) UILabel *label;
@property(nonatomic) BOOL list;
@end
@implementation OLCell
- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        self.icon = [UIImageView new];
        self.icon.contentMode = UIViewContentModeScaleAspectFit;
        // Preserve the system icon's original mask instead of clipping it twice.
        self.icon.layer.magnificationFilter = kCAFilterLinear;
        self.icon.layer.minificationFilter = kCAFilterTrilinear;
        self.icon.layer.shouldRasterize = NO;
        self.label = [UILabel new];
        self.label.textColor = UIColor.whiteColor;
        self.label.font = [UIFont systemFontOfSize:12];
        [self.contentView addSubview:self.icon];
        [self.contentView addSubview:self.label];
        self.isAccessibilityElement = YES;
        self.accessibilityTraits = UIAccessibilityTraitButton;
    }
    return self;
}
- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat w = self.contentView.bounds.size.width;
    self.icon.frame = self.list ? CGRectMake(8, 6, 44, 44) : CGRectMake((w-48)/2, 4, 48, 48);
    self.label.frame = self.list ? CGRectMake(64, 0, MAX(0,w-72), 56) : CGRectMake(0, 56, w, 30);
    self.label.textAlignment = self.list ? NSTextAlignmentLeft : NSTextAlignmentCenter;
    self.label.numberOfLines = self.list ? 1 : 2;
}
@end

// A lightweight glass-inspired surface, not the iOS 26 Liquid Glass API.
// No backdrop filter: the dock's no-blur setting is respected.
@interface OLGlassView : UIView
@property(nonatomic,strong) CAGradientLayer *sheen;
@property(nonatomic,strong) CAShapeLayer *rim;
- (void)configureDark:(BOOL)dark opacity:(CGFloat)opacity;
@end
@implementation OLGlassView
- (instancetype)initWithFrame:(CGRect)frame {
    if ((self=[super initWithFrame:frame])) {
        self.userInteractionEnabled=NO;
        self.backgroundColor=[UIColor colorWithWhite:0.12 alpha:UIAccessibilityIsReduceTransparencyEnabled() ? 0.96 : 0.24];
        self.layer.cornerRadius=28;
        self.layer.shadowColor=UIColor.blackColor.CGColor;
        self.layer.shadowOpacity=0.24; self.layer.shadowRadius=20;
        self.layer.shadowOffset=CGSizeMake(0,9);
        self.sheen=[CAGradientLayer layer];
        self.sheen.colors=@[(id)[UIColor colorWithWhite:1 alpha:0.30].CGColor,
                            (id)[UIColor colorWithWhite:1 alpha:0.055].CGColor,
                            (id)[UIColor colorWithWhite:1 alpha:0.16].CGColor];
        self.sheen.locations=@[@0,@0.48,@1];
        self.sheen.startPoint=CGPointMake(0,0); self.sheen.endPoint=CGPointMake(1,1);
        self.sheen.cornerRadius=28; [self.layer addSublayer:self.sheen];
        self.rim=[CAShapeLayer layer]; self.rim.fillColor=UIColor.clearColor.CGColor;
        self.rim.strokeColor=[UIColor colorWithWhite:1 alpha:0.48].CGColor;
        self.rim.lineWidth=0.75; [self.layer addSublayer:self.rim];
    } return self;
}
- (void)layoutSubviews {
    [super layoutSubviews];
    [CATransaction begin]; [CATransaction setDisableActions:YES];
    self.sheen.frame=self.bounds;
    self.rim.path=[UIBezierPath bezierPathWithRoundedRect:CGRectInset(self.bounds,0.5,0.5) cornerRadius:28].CGPath;
    self.layer.shadowPath=[UIBezierPath bezierPathWithRoundedRect:self.bounds cornerRadius:28].CGPath;
    [CATransaction commit];
}
- (void)configureDark:(BOOL)dark opacity:(CGFloat)opacity {
    CGFloat alpha=UIAccessibilityIsReduceTransparencyEnabled() ? 1 : MAX(0,MIN(1,opacity));
    self.backgroundColor=[UIColor colorWithWhite:dark ? 0.08 : 0.98 alpha:alpha];
    self.sheen.colors=@[(id)[UIColor colorWithWhite:1 alpha:alpha*0.50].CGColor,
                        (id)[UIColor colorWithWhite:1 alpha:alpha*0.08].CGColor,
                        (id)[UIColor colorWithWhite:1 alpha:alpha*0.28].CGColor];
    self.rim.strokeColor=[UIColor colorWithWhite:dark ? 1 : 0.65 alpha:alpha*0.85].CGColor;
}
@end


// UIKit-only dock magnification, compatible with iOS 12 (no SF Symbols).
@interface OLDockLayout : UICollectionViewFlowLayout
@end
@implementation OLDockLayout
- (void)prepareLayout {
    CGFloat side=MAX(16,(self.collectionView.bounds.size.width-72)/2);
    self.sectionInset=UIEdgeInsetsMake(24,side,12,side);
    [super prepareLayout];
}
- (NSArray *)layoutAttributesForElementsInRect:(CGRect)rect {
    NSArray *base = [super layoutAttributesForElementsInRect:CGRectInset(rect,-90,0)];
    NSMutableArray *result = [NSMutableArray array];
    CGFloat focus = self.collectionView.contentOffset.x + self.collectionView.bounds.size.width/2;
    for (UICollectionViewLayoutAttributes *original in base) {
        UICollectionViewLayoutAttributes *a = [original copy];
        CGFloat strength = MAX(0,1-fabs(a.center.x-focus)/115);
        strength = strength*strength*(3-2*strength);
        CGFloat scale = 1+0.5*strength;
        a.transform = CGAffineTransformMakeScale(scale,scale);
        a.center = CGPointMake(a.center.x,a.center.y-12*strength);
        a.zIndex = (NSInteger)(strength*100);
        [result addObject:a];
    }
    return result;
}
- (BOOL)shouldInvalidateLayoutForBoundsChange:(CGRect)bounds { (void)bounds; return YES; }
@end

@interface OLController : UIViewController <UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UISearchBarDelegate>
@property(nonatomic,strong) NSArray *apps;
@property(nonatomic,strong) NSArray *filtered;
@property(nonatomic,strong) NSArray *dockApps;
@property(nonatomic,strong) UIView *panel;
@property(nonatomic,strong) UIView *shelf;
@property(nonatomic,strong) UIVisualEffectView *blur;
@property(nonatomic,strong) UIView *dim;
@property(nonatomic,strong) UICollectionView *collection;
@property(nonatomic,strong) UISearchBar *search;
@property(nonatomic,strong) UIButton *searchButton;
@property(nonatomic,strong) UIButton *closeButton;
@property(nonatomic,strong) UILabel *emptyLabel;
@property(nonatomic,strong) OLGlassView *nameBubble;
@property(nonatomic,strong) UILabel *nameLabel;
@property(nonatomic) CFTimeInterval suppressTapUntil;
@property(nonatomic) BOOL dock;
@property(nonatomic) BOOL list;
@property(nonatomic) BOOL appeared;
@property(nonatomic) BOOL launching;
@property(nonatomic) CGFloat keyboardTop;
@property(nonatomic) BOOL darkTheme;
@property(nonatomic) CGFloat surfaceOpacity;
@end

@implementation OLController
- (BOOL)prefersStatusBarHidden { return YES; }
- (UIInterfaceOrientationMask)supportedInterfaceOrientations { return UIInterfaceOrientationMaskPortrait; }
- (UIImage *)searchGlyph {
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(26,26),NO,0);
    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(3,3,14,14)];
    path.lineWidth = 2.2; [(self.darkTheme ? UIColor.whiteColor : UIColor.blackColor) setStroke]; [path stroke];
    path = [UIBezierPath bezierPath]; [path moveToPoint:CGPointMake(16,16)];
    [path addLineToPoint:CGPointMake(23,23)]; path.lineWidth=2.2;
    path.lineCapStyle=kCGLineCapRound; [path stroke];
    UIImage *image=UIGraphicsGetImageFromCurrentImageContext(); UIGraphicsEndImageContext(); return image;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    NSDictionary *settings=OLSettings();
    self.darkTheme=[settings[@"darkTheme"] boolValue];
    self.surfaceOpacity=MAX(0,MIN(1,[settings[@"surfaceOpacity"] doubleValue]/100.0));
    if (UIAccessibilityIsReduceTransparencyEnabled()) self.surfaceOpacity=1;
    UIColor *text=self.darkTheme ? UIColor.whiteColor : [UIColor colorWithWhite:0.08 alpha:1];
    self.dock=[settings[@"style"] integerValue]==1;
    self.list=[settings[@"list"] boolValue];
    self.keyboardTop=CGFLOAT_MAX;
    NSSet *hidden=[NSSet setWithArray:settings[@"hiddenIDs"]];
    NSMutableArray *apps=[NSMutableArray array];
    for (NSDictionary *app in OLApplications()) if (![hidden containsObject:app[@"id"]]) [apps addObject:app];
    self.apps=apps; self.filtered=apps;
    NSMutableDictionary *catalog=[NSMutableDictionary dictionary];
    for (NSDictionary *app in apps) catalog[app[@"id"]]=app;
    NSMutableArray *dock=[NSMutableArray array];
    NSMutableSet *recentSet=[NSMutableSet set];
    id history=settings[@"recentIDs"];
    if ([history isKindOfClass:NSArray.class]) for (NSString *identifier in history) {
        NSDictionary *app=catalog[identifier];
        if (app && ![recentSet containsObject:identifier] && dock.count<5) {
            [dock addObject:app]; [recentSet addObject:identifier];
        }
    }
    if (dock.count && dock.count<apps.count) [dock addObject:@{@"divider":@YES}];
    for (NSDictionary *app in apps) if (![recentSet containsObject:app[@"id"]]) [dock addObject:app];
    self.dockApps=dock;
    self.view.backgroundColor=UIColor.clearColor;
    self.blur=[[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:self.darkTheme ? UIBlurEffectStyleDark : UIBlurEffectStyleLight]];
    self.blur.frame=self.view.bounds; self.blur.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    self.blur.hidden=self.dock && ![settings[@"dockBlur"] boolValue];
    self.blur.alpha=self.surfaceOpacity;
    [self.view addSubview:self.blur];
    self.dim=[[UIView alloc] initWithFrame:self.view.bounds]; self.dim.autoresizingMask=self.blur.autoresizingMask;
    self.dim.backgroundColor=[UIColor colorWithWhite:self.darkTheme ? 0 : 1 alpha:MAX(0,MIN(0.8,[settings[@"dim"] doubleValue]))];
    self.dim.hidden=self.dock; [self.view addSubview:self.dim];
    self.dim.alpha=self.surfaceOpacity;
    UIControl *backdrop=[[UIControl alloc] initWithFrame:self.view.bounds];
    backdrop.autoresizingMask=self.blur.autoresizingMask;
    [backdrop addTarget:self action:@selector(close) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:backdrop];
    self.panel=[UIView new]; [self.view addSubview:self.panel];
    self.shelf=[OLGlassView new];
    [(OLGlassView *)self.shelf configureDark:self.darkTheme opacity:self.surfaceOpacity];
    [self.panel addSubview:self.shelf];
    self.search=[UISearchBar new]; self.search.placeholder=@"Search apps";
    self.search.searchBarStyle=UISearchBarStyleMinimal; self.search.barStyle=self.darkTheme ? UIBarStyleBlack : UIBarStyleDefault;
    self.search.tintColor=text;
    self.search.delegate=self; [self.panel addSubview:self.search];
    self.closeButton=[UIButton buttonWithType:UIButtonTypeSystem];
    [self.closeButton setTitle:@"×" forState:UIControlStateNormal];
    [self.closeButton setTitleColor:text forState:UIControlStateNormal];
    self.closeButton.titleLabel.font=[UIFont systemFontOfSize:30 weight:UIFontWeightLight];
    self.closeButton.accessibilityLabel=@"Close launcher";
    [self.closeButton addTarget:self action:@selector(close) forControlEvents:UIControlEventTouchUpInside];
    [self.panel addSubview:self.closeButton];
    self.searchButton=[UIButton buttonWithType:UIButtonTypeCustom];
    [self.searchButton setImage:[self searchGlyph] forState:UIControlStateNormal];
    CGFloat buttonOpacity=UIAccessibilityIsReduceTransparencyEnabled() ? 1 : self.surfaceOpacity;
    self.searchButton.backgroundColor=[UIColor colorWithWhite:self.darkTheme ? 0.2 : 1 alpha:buttonOpacity]; self.searchButton.layer.cornerRadius=24;
    self.searchButton.layer.borderColor=[UIColor colorWithWhite:self.darkTheme ? 1 : 0.6 alpha:buttonOpacity*0.8].CGColor;
    self.searchButton.layer.borderWidth=0.75;
    self.searchButton.accessibilityLabel=@"Search apps";
    [self.searchButton addTarget:self action:@selector(openSearch) forControlEvents:UIControlEventTouchUpInside];
    [self.panel addSubview:self.searchButton];
    self.collection=[[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:[self layout]];
    self.collection.backgroundColor=UIColor.clearColor; self.collection.dataSource=self; self.collection.delegate=self;
    self.collection.showsHorizontalScrollIndicator=NO;
    self.collection.decelerationRate=UIScrollViewDecelerationRateFast;
    self.collection.keyboardDismissMode=UIScrollViewKeyboardDismissModeOnDrag;
    [self.collection registerClass:OLCell.class forCellWithReuseIdentifier:@"app"];
    [self.collection registerClass:UICollectionViewCell.class forCellWithReuseIdentifier:@"divider"];
    [self.panel addSubview:self.collection];
    UILongPressGestureRecognizer *hold=[[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(holdApp:)];
    hold.minimumPressDuration=0.35; hold.cancelsTouchesInView=YES;
    [self.collection addGestureRecognizer:hold];
    self.nameBubble=[OLGlassView new]; self.nameBubble.hidden=YES;
    // Keep the name readable even over bright wallpaper without adding dock blur.
    [self.nameBubble configureDark:self.darkTheme opacity:self.surfaceOpacity];
    self.nameLabel=[UILabel new]; self.nameLabel.textColor=text;
    self.nameLabel.textAlignment=NSTextAlignmentCenter; self.nameLabel.numberOfLines=2;
    self.nameLabel.font=[UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
    [self.nameBubble addSubview:self.nameLabel]; [self.view addSubview:self.nameBubble];
    self.emptyLabel=[UILabel new]; self.emptyLabel.textColor=text;
    self.emptyLabel.font=[UIFont systemFontOfSize:14]; self.emptyLabel.numberOfLines=0;
    self.emptyLabel.textAlignment=NSTextAlignmentCenter; [self.panel addSubview:self.emptyLabel];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboard:) name:UIKeyboardWillChangeFrameNotification object:nil];
    self.view.accessibilityViewIsModal=YES;
    [self updateMode];
}
- (UICollectionViewFlowLayout *)layout {
    UICollectionViewFlowLayout *layout=self.dock ? [OLDockLayout new] : [UICollectionViewFlowLayout new];
    layout.scrollDirection=self.dock ? UICollectionViewScrollDirectionHorizontal : UICollectionViewScrollDirectionVertical;
    layout.minimumInteritemSpacing=4; layout.minimumLineSpacing=self.dock ? 4 : 12;
    layout.sectionInset=self.dock ? UIEdgeInsetsMake(24,20,12,20) : UIEdgeInsetsZero;
    return layout;
}
- (void)updateMode {
    self.shelf.hidden=NO; self.searchButton.hidden=!self.dock;
    self.search.hidden=self.dock; self.closeButton.hidden=self.dock;
    self.emptyLabel.hidden=self.filtered.count>0;
    self.emptyLabel.text=self.apps.count ? @"No matching apps" : @"Choose apps in Settings → Orbit Launcher";
}
- (void)dealloc { [[NSNotificationCenter defaultCenter] removeObserver:self]; }
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    if (!self.appeared && !UIAccessibilityIsReduceMotionEnabled()) self.panel.alpha=0;
}
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    if (self.appeared) return; self.appeared=YES;
    [self animateIn];
}
- (void)animateIn {
    if (UIAccessibilityIsReduceMotionEnabled()) return;
    self.panel.transform=self.dock ? CGAffineTransformConcat(CGAffineTransformMakeScale(0.82,0.82),CGAffineTransformMakeTranslation(0,100)) : CGAffineTransformMakeTranslation(0,self.view.bounds.size.height);
    self.panel.alpha=0;
    self.blur.alpha=0; self.dim.alpha=0;
    [UIView animateWithDuration:self.dock ? 0.55 : 0.44 delay:0 usingSpringWithDamping:self.dock ? 0.7 : 0.9 initialSpringVelocity:0.5 options:UIViewAnimationOptionBeginFromCurrentState animations:^{
        self.panel.transform=CGAffineTransformIdentity; self.panel.alpha=1; self.blur.alpha=self.surfaceOpacity; self.dim.alpha=self.surfaceOpacity;
    } completion:nil];
}
- (void)close {
    if (UIAccessibilityIsReduceMotionEnabled()) { OLDismiss(); return; }
    self.view.userInteractionEnabled=NO;
    UIWindow *window=self.view.window;
    [UIView animateWithDuration:0.18 animations:^{
        self.panel.transform=CGAffineTransformMakeTranslation(0,self.dock ? 170 : self.view.bounds.size.height);
        self.view.alpha=0;
    } completion:^(BOOL finished) { (void)finished; if (OLWindow==window) OLDismiss(); }];
}
- (BOOL)accessibilityPerformEscape { [self close]; return YES; }
- (void)openSearch {
    self.dock=NO; self.blur.hidden=NO; self.dim.hidden=NO;
    [self.collection setCollectionViewLayout:[self layout] animated:NO];
    [self updateMode]; [self.collection reloadData]; [self.view setNeedsLayout]; [self.view layoutIfNeeded];
    [self animateIn]; [self.search becomeFirstResponder];
}
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    CGFloat w=self.view.bounds.size.width,h=self.view.bounds.size.height;
    CGFloat bottom=MAX(12,self.view.safeAreaInsets.bottom),top=MAX(12,self.view.safeAreaInsets.top);
    // Set bounds/center rather than frame while the presentation transform is animating.
    CGSize size=self.dock ? CGSizeMake(w,148) : CGSizeMake(w,h-top);
    self.panel.bounds=(CGRect){CGPointZero,size};
    self.panel.center=self.dock ? CGPointMake(w/2,h-bottom-74) : CGPointMake(w/2,top+size.height/2);
    self.shelf.frame=self.dock ? CGRectMake(10,40,w-20,96) : CGRectMake(6,0,w-12,size.height-bottom);
    self.collection.frame=self.dock ? CGRectMake(76,20,w-86,124) : CGRectMake(12,64,w-24,MAX(0,size.height-64-bottom));
    self.search.frame=CGRectMake(8,8,w-60,48); self.closeButton.frame=CGRectMake(w-50,8,44,48);
    self.searchButton.frame=CGRectMake(18,58,48,48);
    self.emptyLabel.frame=self.dock ? CGRectMake(24,40,w-48,60) : CGRectMake(24,100,w-48,100);
    [self.collection.collectionViewLayout invalidateLayout];
    [self updateKeyboardInset];
}
- (void)keyboard:(NSNotification *)notification {
    CGRect frame=[self.view convertRect:[notification.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue] fromView:nil];
    self.keyboardTop=CGRectGetMinY(frame); [self updateKeyboardInset];
}
- (void)updateKeyboardInset {
    CGFloat bottom=[self.collection convertPoint:CGPointMake(0,self.collection.bounds.size.height) toView:self.view].y;
    CGFloat inset=self.dock ? 0 : MAX(0,bottom-self.keyboardTop);
    self.collection.contentInset=UIEdgeInsetsMake(0,0,inset,0); self.collection.scrollIndicatorInsets=self.collection.contentInset;
}
- (void)searchBar:(UISearchBar *)bar textDidChange:(NSString *)text {
    self.nameBubble.hidden=YES;
    (void)bar; self.filtered=OLFilter(self.apps,text); [self.collection reloadData]; [self updateMode];
}
- (void)searchBarSearchButtonClicked:(UISearchBar *)bar { [bar resignFirstResponder]; }
- (NSArray *)displayApps { return self.dock ? self.dockApps : self.filtered; }
- (NSInteger)collectionView:(UICollectionView *)view numberOfItemsInSection:(NSInteger)section {
    (void)view; (void)section; return [self displayApps].count;
}
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)view cellForItemAtIndexPath:(NSIndexPath *)index {
    NSDictionary *app=[self displayApps][index.item];
    if ([app[@"divider"] boolValue]) {
        UICollectionViewCell *divider=[view dequeueReusableCellWithReuseIdentifier:@"divider" forIndexPath:index];
        if (!divider.contentView.subviews.count) {
            UIView *line=[[UIView alloc] initWithFrame:CGRectMake(11,8,1,42)];
            line.backgroundColor=[UIColor colorWithWhite:self.darkTheme ? 1 : 0 alpha:0.25];
            [divider.contentView addSubview:line];
        }
        divider.isAccessibilityElement=NO; return divider;
    }
    OLCell *cell=[view dequeueReusableCellWithReuseIdentifier:@"app" forIndexPath:index];
    cell.list=!self.dock && self.list;
    cell.icon.image=OLIcon(app[@"id"]); cell.label.text=app[@"name"]; cell.label.hidden=self.dock;
    cell.label.textColor=self.darkTheme ? UIColor.whiteColor : [UIColor colorWithWhite:0.08 alpha:1];
    cell.accessibilityLabel=app[@"name"]; [cell setNeedsLayout]; return cell;
}
- (CGSize)collectionView:(UICollectionView *)view layout:(UICollectionViewLayout *)layout sizeForItemAtIndexPath:(NSIndexPath *)index {
    (void)layout;
    if (self.dock && [[self displayApps][index.item][@"divider"] boolValue]) return CGSizeMake(24,72);
    if (self.dock) return CGSizeMake(72,72);
    CGFloat width=view.bounds.size.width; NSInteger columns=MAX(1,(NSInteger)floor(width/70));
    return self.list ? CGSizeMake(width,56) : CGSizeMake(floor((width-(columns-1)*4)/columns),90);
}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    (void)scrollView; self.nameBubble.hidden=YES;
    if (self.dock) [self.collection.collectionViewLayout invalidateLayout];
}
- (void)holdApp:(UILongPressGestureRecognizer *)gesture {
    // Recognition cancels the collection's tap: releasing a hold never launches.
    self.suppressTapUntil=CACurrentMediaTime()+0.3;
    if (gesture.state==UIGestureRecognizerStateBegan || gesture.state==UIGestureRecognizerStateChanged) {
        NSIndexPath *index=[self.collection indexPathForItemAtPoint:[gesture locationInView:self.collection]];
        if (!index || (NSUInteger)index.item>=[self displayApps].count || [[self displayApps][index.item][@"divider"] boolValue]) { self.nameBubble.hidden=YES; return; }
        OLCell *cell=(OLCell *)[self.collection cellForItemAtIndexPath:index];
        self.nameLabel.text=[self displayApps][index.item][@"name"];
        CGFloat w=MIN(240,self.view.bounds.size.width-32);
        CGSize text=[self.nameLabel sizeThatFits:CGSizeMake(w-28,80)];
        CGFloat height=MAX(48,text.height+24);
        CGRect icon=[cell.icon convertRect:cell.icon.bounds toView:self.view];
        CGFloat x=MAX(16,MIN(self.view.bounds.size.width-w-16,CGRectGetMidX(icon)-w/2));
        CGFloat y=CGRectGetMinY(icon)-height-12;
        if (y<MAX(12,self.view.safeAreaInsets.top)) y=CGRectGetMaxY(icon)+12;
        y=MAX(12,MIN(self.view.bounds.size.height-height-12,y));
        self.nameBubble.frame=CGRectMake(x,y,w,height);
        self.nameLabel.frame=CGRectMake(14,8,w-28,height-16);
        BOOL wasHidden=self.nameBubble.hidden; self.nameBubble.hidden=NO;
        [self.view bringSubviewToFront:self.nameBubble];
        if (wasHidden && !UIAccessibilityIsReduceMotionEnabled()) {
            self.nameBubble.alpha=0;
            [UIView animateWithDuration:0.18 animations:^{self.nameBubble.alpha=1;}];
        }
    } else { self.nameBubble.hidden=YES; }
}
- (void)collectionView:(UICollectionView *)view didSelectItemAtIndexPath:(NSIndexPath *)index {
    (void)view;
    if ([[self displayApps][index.item][@"divider"] boolValue]) return;
    if (CACurrentMediaTime()<self.suppressTapUntil) return;
    if (self.launching || !OLCanPresent()) { OLDismiss(); return; }
    self.launching=YES;
    NSString *identifier=[[self displayApps][index.item][@"id"] copy];
    // Remove our key window before requesting activation. LS IPC can block and its
    // BOOL is not confirmation that the app did/didn't become foreground on iOS 12.
    OLDismiss();
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0), ^{
        @autoreleasepool { if (!OLOpen(identifier)) NSLog(@"[OrbitLauncher] Launch request returned NO for %@ (foreground result unconfirmed)",identifier); }
    });
}
@end

static void OLPreferencesChanged(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef info) {
    (void)center; (void)observer; (void)name; (void)object; (void)info;
    dispatch_async(dispatch_get_main_queue(), ^{ OLDismiss(); });
}

BOOL OLToggle(void) {
    NSCAssert([NSThread isMainThread], @"UI must run on main thread");
    if (OLWindow) { OLDismiss(); return YES; }
    if (!OLCanPresent()) return NO;
    OLCaptureFrontApp();
    if (!OLObserversInstalled) {
        OLObserversInstalled = YES;
        // Any lock transition closes the overlay. Never display over authentication UI.
        static int lockToken, displayToken;
        notify_register_dispatch("com.apple.springboard.lockstate", &lockToken, dispatch_get_main_queue(), ^(int token) {
            (void)token; OLDismiss();
        });
        notify_register_dispatch("com.apple.iokit.hid.displayStatus", &displayToken, dispatch_get_main_queue(), ^(int token) {
            uint64_t state = 0;
            if (notify_get_state(token,&state) == NOTIFY_STATUS_OK && state == 0) OLDismiss();
        });
        CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL,
            OLPreferencesChanged, OLChanged, NULL, CFNotificationSuspensionBehaviorDeliverImmediately);
    }
    OLPreviousWindow = UIApplication.sharedApplication.keyWindow;
    OLWindow = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    OLWindow.backgroundColor = UIColor.clearColor;
    OLWindow.windowLevel = UIWindowLevelAlert + 1;
    OLWindow.rootViewController = [OLController new];
    [OLWindow makeKeyAndVisible];
    UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, nil);
    return YES;
}
