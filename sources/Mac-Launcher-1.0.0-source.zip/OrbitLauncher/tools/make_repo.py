#!/usr/bin/env python3
"""Generate a flat, rootful APT repo locally. Never uploads or signs anything."""
import argparse
import bz2
from datetime import datetime, timezone
from email.utils import format_datetime
import gzip
import hashlib
import os
from pathlib import Path
import re
import subprocess

INDEXES = ("Packages", "Packages.gz", "Packages.bz2")
GENERATED_FIELDS = {"Filename", "Size", "MD5sum", "SHA1", "SHA256", "SHA512"}


def parse_control(text):
    fields = {}
    current = None
    for line in text.splitlines():
        if not line:
            continue
        if line[0].isspace():
            if current is None:
                raise ValueError("Control continuation without field")
            fields[current] += "\n" + line
        else:
            key, separator, value = line.partition(":")
            if not separator or not re.fullmatch(r"[A-Za-z0-9-]+", key) or key in fields:
                raise ValueError(f"Invalid or duplicate control field: {line!r}")
            current = key
            fields[key] = value.lstrip()
    for key in ("Package", "Version", "Architecture", "Description"):
        if not fields.get(key) or "\n" in fields[key] and key != "Description":
            raise ValueError(f"Missing or invalid control field: {key}")
    return fields


def package_record(root, deb):
    if deb.is_symlink() or not deb.resolve().is_relative_to(root.resolve()):
        raise ValueError("Package must be a regular file inside repo")
    relative = deb.relative_to(root).as_posix()
    if not re.fullmatch(r"[A-Za-z0-9_./+~-]+", relative):
        raise ValueError("Package paths must use URL-safe ASCII without spaces")
    result = subprocess.run(["dpkg-deb", "--field", str(deb.resolve())],
                            check=True, capture_output=True, text=True, encoding="utf-8")
    fields = parse_control(result.stdout)
    if fields["Architecture"] not in ("iphoneos-arm", "all"):
        raise ValueError(f"Expected rootful architecture, got {fields['Architecture']}")
    fields = {k: v for k, v in fields.items() if k not in GENERATED_FIELDS}
    data = deb.read_bytes()
    fields.update(Filename="./" + relative, Size=str(len(data)),
                  MD5sum=hashlib.md5(data).hexdigest(), SHA256=hashlib.sha256(data).hexdigest(),
                  SHA512=hashlib.sha512(data).hexdigest())
    return fields


def atomic_write(path, data):
    temp = path.with_name(path.name + ".tmp")
    temp.write_bytes(data)
    os.replace(temp, path)


def write_indexes(root, records, label, now=None):
    if not label or any(c in label for c in "\r\n"):
        raise ValueError("Label must be a single nonempty line")
    packages = "".join("".join(f"{k}: {v}\n" for k, v in record.items()) + "\n"
                       for record in records).encode("utf-8")
    payloads = {"Packages": packages, "Packages.gz": gzip.compress(packages, mtime=0),
                "Packages.bz2": bz2.compress(packages)}
    now = now or datetime.now(timezone.utc)
    lines = [f"Origin: {label}", f"Label: {label}", "Suite: stable", "Codename: stable",
             "Version: 1.0", "Architectures: iphoneos-arm", "Components: main",
             "Description: Rootful iOS 12 jailbreak packages", f"Date: {format_datetime(now, usegmt=True)}"]
    for heading, algorithm in (("MD5Sum", "md5"), ("SHA256", "sha256"), ("SHA512", "sha512")):
        lines.append(heading + ":")
        for name, data in payloads.items():
            lines.append(f" {hashlib.new(algorithm, data).hexdigest()} {len(data)} {name}")
    # Generate in a local staging directory. Multi-file publication must be handled by host.
    for name, data in payloads.items():
        atomic_write(root / name, data)
    atomic_write(root / "Release", ("\n".join(lines) + "\n").encode("utf-8"))
    # Existing signatures would now be invalid. Refuse before generation in main instead.


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path, help="Local staging directory containing debs/")
    parser.add_argument("--label", default="Orbit Launcher Development")
    parser.add_argument("--allow-empty", action="store_true", help="Create an empty scaffold only")
    args = parser.parse_args()
    root = args.root.resolve()
    root.mkdir(parents=True, exist_ok=True)
    if any((root / name).exists() for name in ("InRelease", "Release.gpg")):
        parser.error("Use a fresh staging directory; existing signatures must not be reused")
    debs = sorted((root / "debs").rglob("*.deb"))
    if not debs and not args.allow_empty:
        parser.error("No .deb files under debs/. Build and copy a real package first")
    try:
        records = [package_record(root, deb) for deb in debs]
        seen = set()
        for record in records:
            key = tuple(record[k] for k in ("Package", "Version", "Architecture"))
            if key in seen:
                raise ValueError(f"Duplicate package/version/architecture: {key}")
            seen.add(key)
        write_indexes(root, records, args.label)
    except (ValueError, OSError, subprocess.CalledProcessError) as error:
        parser.error(str(error))
    print(f"Generated {len(records)} package record(s) in {root}; nothing uploaded.")


if __name__ == "__main__":
    main()
