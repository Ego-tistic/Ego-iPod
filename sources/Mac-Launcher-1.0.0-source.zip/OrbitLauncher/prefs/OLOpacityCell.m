#import <Preferences/PSTableCell.h>
#import <Preferences/PSSpecifier.h>
#import "../Shared.h"
#import "../Opacity.h"

@interface OLSteppedSlider : UISlider
@end
@implementation OLSteppedSlider
- (void)accessibilityIncrement {
    self.value=OLSteppedOpacity(self.value+5);
    [self sendActionsForControlEvents:UIControlEventValueChanged];
    [self sendActionsForControlEvents:UIControlEventTouchUpInside];
}
- (void)accessibilityDecrement {
    self.value=OLSteppedOpacity(self.value-5);
    [self sendActionsForControlEvents:UIControlEventValueChanged];
    [self sendActionsForControlEvents:UIControlEventTouchUpInside];
}
@end

@interface OLOpacityCell : PSTableCell
@property(nonatomic,strong) UILabel *heading;
@property(nonatomic,strong) UILabel *amount;
@property(nonatomic,strong) OLSteppedSlider *slider;
@end
@implementation OLOpacityCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)identifier specifier:(PSSpecifier *)specifier {
    if ((self=[super initWithStyle:style reuseIdentifier:identifier specifier:specifier])) {
        self.selectionStyle=UITableViewCellSelectionStyleNone;
        self.heading=[UILabel new]; self.heading.text=@"Surface Opacity";
        self.heading.font=[UIFont systemFontOfSize:16];
        self.amount=[UILabel new]; self.amount.font=[UIFont monospacedDigitSystemFontOfSize:15 weight:UIFontWeightRegular];
        self.amount.textAlignment=NSTextAlignmentRight;
        self.slider=[OLSteppedSlider new]; self.slider.minimumValue=0; self.slider.maximumValue=100;
        self.slider.value=[OLSettings()[@"surfaceOpacity"] floatValue];
        self.slider.accessibilityLabel=@"Surface opacity";
        [self.slider addTarget:self action:@selector(changed) forControlEvents:UIControlEventValueChanged];
        [self.slider addTarget:self action:@selector(save) forControlEvents:UIControlEventTouchUpInside|UIControlEventTouchUpOutside|UIControlEventTouchCancel];
        [self.contentView addSubview:self.heading]; [self.contentView addSubview:self.amount]; [self.contentView addSubview:self.slider];
        [self changed];
    } return self;
}
- (void)layoutSubviews {
    [super layoutSubviews]; self.textLabel.hidden=YES; self.detailTextLabel.hidden=YES;
    CGFloat w=self.contentView.bounds.size.width;
    self.heading.frame=CGRectMake(16,8,w-100,24); self.amount.frame=CGRectMake(w-80,8,64,24);
    self.slider.frame=CGRectMake(16,36,w-32,36);
}
- (void)changed {
    self.slider.value=OLSteppedOpacity(self.slider.value);
    NSString *value=[NSString stringWithFormat:@"%.0f%%",self.slider.value];
    self.amount.text=value; self.slider.accessibilityValue=value;
}
- (void)save {
    [self changed];
    if (!OLWriteSetting(@"surfaceOpacity",@(self.slider.value))) {
        self.slider.value=[OLSettings()[@"surfaceOpacity"] floatValue]; [self changed];
        self.amount.text=@"Not saved";
    }
}
@end
