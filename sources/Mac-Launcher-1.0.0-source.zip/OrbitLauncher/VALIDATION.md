# Ego-iPod publication preparation

The existing repository source was found at Ego-tistic/Pro-Pods-Repo. Its Pro-Pods 1.0.2~diagnostic2 package is preserved byte for byte. Mac-Launcher 1.0.0 is added alongside it, with open-source archive and MIT license. The requested new repository name/Pages address are Ego-iPod and https://ego-tistic.github.io/Ego-iPod/. This is a GitHub repository rename, not only a display label change. Old project Pages URLs should not be relied upon to redirect. Publication state must be checked on GitHub/the actual hosted files; local preparation alone is not a live deployment.

# Mac-Launcher 1.0.0 release build

Surface Opacity now snaps to 0%, 5%, 10%, …, 100% during dragging, displays the selected percentage, and persists on release. VoiceOver increment/decrement also moves exactly 5%. Older stored values are rounded when read; new writes are clamped and quantized centrally. A dedicated Preferences cell keeps the displayed thumb/value consistent. The default is 35%. Native C tests cover all step boundaries, midpoint rounding, invalid numbers, clamping and 3,001 sampled inputs; host binary/signature and repo tests passed. The updated Settings control still needs device interaction testing.

The requested repository display name is Ego-iPod. Do not rename a GitHub user-site repository or replace an existing full Packages index without reviewing its actual source. The provided https://ego-tistic.github.io returned HTTP 404 during this session; the inferred public source repository was inaccessible too. A separate Ego-iPod-staging folder is a local single-package preparation only; it has not been merged into the existing ProPods repo, published or pushed. Its Release Origin/Label are Ego-iPod. Existing package preservation, hosting configuration, signing and final publication require the actual source repo.

# Mac-Launcher 0.5.0

The product is now named Mac-Launcher in Settings, Activator and package metadata, with a custom Mac-style computer Settings icon at 1x/2x/3x. The internal package ID/domain and bundle names stay the same so this upgrades the existing install and preserves selections and assignments.

The dock starts with a separate, unlabeled recent-app section (up to five unique apps, newest first), followed by a divider and remaining chosen apps without duplicates. The drawer/search continues to use its original selected-app catalog and alphabetical ordering. Launcher-hidden and uninstalled apps are not displayed in recents. No placeholder/random apps fill an empty history; the five slots fill as you use apps after installation. History stores five IDs locally and persists across resprings. Existing system usage history is not imported.

Recency is recorded from the guarded private SpringBoard frontDisplayDidChange: callback, not from speculative launcher taps, so foreground changes from outside the launcher can count too. On opening the launcher a guarded _accessibilityFrontMostApplication query seeds the current app. These private callbacks/selectors require testing on the actual iOS 12.5.8 device. If unavailable, complete tracking is not guaranteed. No Home-button interception was added. Source reference for the callback shape: https://github.com/DGh0st/DVirtualHome/blob/master/Tweak.xm . The new code is an independent implementation.

Device checks: open six different allowed apps from Home Screen and from this launcher, verify newest-first eviction/deduplication, respring persistence, hide/uninstall a recent app, hold a recent icon, tap the divider (must not launch), search from the dock and check that the drawer order is unchanged. Existing light/dark, opacity, magnification, accessibility, lock safety and launch-close checks still apply. Host build/signature checks do not prove runtime recency tracking.

## Version 0.4.0: theme and transparency controls

Settings → Orbit Launcher now includes a Dark Theme switch (on = dark, off = light) and a Surface Opacity slider (0–100, default 35). The slider changes glass panel opacity, borders/highlights, search-button fill and backdrop strength, without fading app icons or text. Dock background blur remains independently disabled unless enabled by its existing switch. The theme also changes the drawer blur style, search-bar appearance, icons' text labels, search glyph, close control, empty state and long-press tooltip. Changes apply on reopening the launcher, without a respring. Reopen Settings after upgrading to load the new preference bundle.

Reduce Transparency overrides the slider with solid surfaces for readability. At zero opacity, surface decoration/backdrop fade away; this is not a blur-radius control. Verify dark/light × opacity 0/35/100 in the drawer and dock, with dock blur enabled/disabled, long-press labels, search/keyboard, and Reduce Transparency on the actual device. Host package checks do not prove visual contrast or slider interaction on the device.


## Version 0.3.0: glass and icon quality

Both layouts now use lightweight translucent gradient surfaces, specular rims and shadows. This is a glass-inspired iOS 12 implementation, not Apple's native iOS 26 Liquid Glass renderer or optical refraction. The dock still has no backdrop blur unless Blur Behind Dock is enabled. Reduce Transparency uses an opaque backing; Reduce Motion retains the previous nonmoving fallback.

Icon loading requests format 2 at scale 3 or higher and checks returned CGImage pixels against the magnified 72pt icon. Format 0 is retained only as a fallback if it returns more pixels. No small image is redrawn/upscaled into a fake high-resolution asset; system icon masking is preserved instead of clipping it again. Actual returned pixel sizes and parity with themed Home Screen icons need device checking. Format 0's small-icon use can be seen in the upstream [AppList implementation](https://github.com/rpetrich/AppList/blob/master/ALApplicationList.x). No AppList runtime dependency was added.

Hold an app for 0.35 seconds to show its name above the icon (or below if it is at the top). Move across icons while holding to change the name. Release to dismiss the name; holding does not launch. Tap normally to launch. The tooltip is outside the scrolling surface so it is not clipped by the dock. Check hold versus drag/tap interaction, long names, top-row icons, keyboard visibility, VoiceOver, scrolling and first/last dock items on the device.

Compilation/package/signature checks are host checks only. Native Liquid Glass, actual icon pixel output, visual polish/performance on A8 and the new long-press behavior have not been verified on an iPod in this environment.

# Version 0.2.0 update

The 0.2.0 source has been rebuilt for arm64 using the iOS 12.4 SDK and deployment target 12.0. See validation-results.txt for checks against the current binary. Earlier 0.1.0 evidence below is retained as build history, not as the current package checksum.

Changes: no title, spring dock entrance, bottom-up drawer animation, left-side drawn magnifying glass, horizontal continuous dock scrolling with magnification, dock blur disabled by default with a preference switch, and an in-memory icon cache. Reduce Motion skips entrance/exit movement.

App selection dismisses the overlay before issuing exactly one LaunchServices request on a background queue. A false BOOL return no longer generates an alert or leaves the launcher open. We cannot infer foreground success from that return value. No retries or alternate activation requests are issued. App launch latency, lock transitions during launch and visual smoothness must be checked on the iPod; there is no measured speed claim.

The old arc/page acceptance checks below are historical. For 0.2.0, instead test continuous scrolling to the first and last apps, magnification while dragging/decelerating, left-side search, keyboard/result selection, zero/one/many apps, dock blur off/on, Reduce Motion, and repeated open/close cycles. Verify both drawer and dock disappear immediately on selection without a false error popup.

## Earlier build audit

# Compatibility audit and validation record

## Checks completed on November 4, 2026

- Installed Microsoft WSL 3.0.3, enabled VirtualMachinePlatform, and continued after the user restarted Windows. Installed Ubuntu and build dependencies. Used the dedicated unprivileged `orbitbuild` user under `/opt/orbit-build` to compile with Theos; no passwordless sudo was granted.
- Built a real rootful `.deb` using Theos commit `6e7b8c40e0f5f9f5b2377800dc1e42cd2560d24a`, Clang 11.1.0 from L1ghtmann toolchain release `test-210562a`, and Theos SDK archive `iPhoneOS12.4.sdk` release `master-146e41f`. Both makefiles target arm64/iOS 12.0 and use `-S -Cadhoc` signing.
- Fixed C linkage declarations across Logos Objective-C++ and Objective-C, normalized Windows-origin resource/control directory permissions, and completed compile/link/sign/package steps successfully. The build's informational plist-optimization notice does not affect validity; XML plists parse successfully.
- Inspected the actual package with dpkg-deb. Verified both Mach-O binaries are thin arm64 dylibs with minimum OS 12.0 and SDK 12.4, correct rootful dependency paths, and valid hashes for every signed code page. Verified package/control scripts, uid/gid 0 ownership, no world-writable payload, no rootless paths, and preference XML. Package SHA256: `898cc98b218a226c0afb4ecb71648939fdc17ab0ca301d0c3997e59baa33aca6`.
- Download archive SHA256 values: toolchain `a72a7a577e2fbe2838b6b5e9c72034fa7d114af96f0e1d4b016f18730ce4056e`; SDK `6880a737bebc179e282aa6990c602536a2f9fe1614c4b3e0cc0a9a9a359145f7`. These record the downloaded bytes; the upstream asset API did not supply an independent published digest.
- Reviewed the iOS 12.0 runtime header snapshot at [nst/iOS-Runtime-Headers commit fbb634c](https://github.com/nst/iOS-Runtime-Headers/tree/fbb634c78269b0169efdead80955ba64eaaa2f21). This is evidence for iOS 12.0 signatures only, not a claim of an iOS 12.5.8 device dump.
- Compared Preferences use with [Theos headers commit 13c1f17](https://github.com/theos/headers/tree/13c1f17176d7efe6871551cd69a75b71ac4eeaf1/Preferences). Added the declaration of `setValues:titles:` missing from the minimal Theos header. Used `-table`, which is in the iOS 12 runtime header, for the picker's search bar.
- Checked Activator listener/handled-event API and mode constants against [upstream headers](https://github.com/rpetrich/libactivator/tree/headers); checked the [Theos rootful Activator stub](https://github.com/theos/lib/blob/master/libactivator.tbd) exports the referenced class/mode symbols. No unsupported raw-button hook is included.
- Host Python checks: repository unit tests, XML plist parsing, UTF-8/LF source checks, and scaffold index decompression/hash verification. See the delivered validation-results.txt for actual output.

## API choices

| API | Basis and behavior |
| --- | --- |
| UICollectionView, UITableView preferences, UISearchBar | Available before iOS 12; no diffable data source, SwiftUI, scenes, or modern list configurations. |
| UIVisualEffectView / dark UIBlurEffect | Available since iOS 8; custom transparent UIWindow in SpringBoard. Actual compositing over apps must be checked on-device. |
| safeAreaInsets | Available since iOS 11. |
| UIKit colors/font/layout | Fixed white/clear colors and system fonts; no iOS 13 dynamic system colors or SF Symbols. Portrait UI, designed for 320×568-point iPod display; verify invocation from a landscape app. |
| LSApplicationWorkspace defaultWorkspace / allApplications / openApplicationWithBundleID: | Private selectors present in the iOS 12 runtime snapshot; runtime class/selector guards and exception handling. MobileCoreServices is linked to load the runtime classes on iOS 12. |
| LSApplicationProxy applicationIdentifier / localizedName / appTags / applicationType | Private metadata, guarded. Hidden-tag filtering is a catalog heuristic, not a launchability guarantee. |
| UIImage _applicationIconImageForBundleIdentifier:format:scale: | Private selector, format int / scale double on arm64. Guarded with nil fallback. Labels remain usable if icons fail. |
| SBLockScreenManager sharedInstance / isUILocked | Private selector; guards fail closed if missing. Not used to unlock or authenticate. |
| com.apple.springboard.lockstate and com.apple.iokit.hid.displayStatus | Darwin notification names are private conventions. Lock transitions close the window; display state 0 closes it. Device testing must verify notifications. |
| CFPreferences | Public preference domain synchronization and Darwin change signal; Settings and SpringBoard normally run as mobile. No direct writes to SpringBoard preferences. |
| libactivator listener | Real dependency with build stub, not a copied recognizer or bundled Activator binary. Registration inside SpringBoard, compatible Home/Application modes only, handled only on acceptance. |

Private API guards reduce missing-selector failures; they do not prove semantic compatibility. ARC memory management and UIKit work are on the main thread. There are no calls to uninstall, icon model mutation, SpringBoard hidden-app configuration, or filesystem icon-state writes.

## Required build acceptance checks

On a configured Theos host:

1. Build with deployment target 12.0 and, ideally, a 12.x SDK. Resolve any compiler/linker errors before calling the artifact installable.
2. Inspect `.deb` architecture `iphoneos-arm`, dependency metadata, default rootful paths, executable maintainer-script modes, and SpringBoard-only filter.
3. Inspect tweak and preference bundle with lipo/otool: arm64, minimum deployment iOS 12.0, correct `/usr/lib/libactivator.dylib` and system framework paths, no `/var/jb` dependencies.
4. Check ad-hoc signatures. Run tests/repo generator against the actual built package. The metadata unit tests use mocked dpkg output; the separate `tools/verify_deb.py` was run against the real delivered package and validates its signed code pages.

## Required iPod acceptance checks

Use the actual iPod touch 6 running the user's stated iOS 12.5.8/Amethyst environment. Record the actual firmware/build, jailbreak/bootstrap/injection versions, Activator version, and any other Home-hook tweaks. Confirm rootful paths and dependency providers from the device; they are not inferred from the jailbreak name.

1. **Baseline:** record normal icon pages/folders/dock. Verify Activator recognizes a physical Home triple-press for a known action before testing Orbit. Test single/double/long Home actions too.
2. **Preferences:** confirm Orbit loads in Settings; switch styles/list/dimming; toggle individual apps; Hide All then select several; Show All; search by name/bundle ID; refresh after installing/uninstalling an app; relaunch Settings and respring to verify persistence.
3. **Drawer:** invoke at Home and inside several apps; grid/list scroll; search accented and duplicate names; empty/no-results states; launch Apple, App Store and jailbreak apps. App launch should close the overlay; stale/restricted entries should fail gracefully.
4. **Arc:** test 0, 1, 2, 3, 4, 5 and many selected apps, every page and both swipe directions, first/last page button disabling, label clipping and tap targets. Ensure all selected apps are reachable on the 320-point display.
5. **Background:** confirm visible blur/dim over both Home and a foreground app. Test Reduce Transparency, Reduce Motion and VoiceOver. Any blur performance issue on A8 needs measurement; do not promise a frame rate from source review.
6. **Dismissal/focus:** Close, backdrop, repeated triple-press, normal Home, keyboard show/hide, switching apps, alerts and returning focus to the app. Invoking from a landscape app must not trap orientation or input.
7. **Lock safety:** show Orbit then press Sleep, wait for automatic lock, and test other lock paths. It must disappear and never remain over the passcode/lock UI; triple-press while locked must not launch anything. Launch while a lock transition occurs must not bypass authentication. Verify both private notification names on this OS. Do not release until this passes.
8. **Gesture conflicts:** Accessibility Shortcut enabled/disabled, Activator per-mode versus Anywhere assignments, another Home action, disabled Orbit, Activator missing/disabled. Preserve an accessibility shortcut if needed; use another gesture for Orbit. Ensure no duplicate activation or app-switcher interference.
9. **Lifecycle:** package install, upgrade, removal, respring, reboot/rejailbreak, Settings reopening after upgrade, low-memory behavior, and a long scroll session. Confirm no icon reordering/hiding/uninstalling and no persistent overlay after removal.
10. **Repo:** test Cydia and Zebra index refresh/dependency resolution, trusted signatures where supported, install/update/uninstall from the actual HTTPS host, and continued access to previously cached package URLs.

The build/package checks described above passed on the host. The iPod checks remain pending. This project contains no device simulator pretending to validate SpringBoard and no Amethyst-specific bootstrap assumptions. The binary is compiled and inspected, not device-tested.
