#!/usr/bin/env python3
"""Inspect Mac-Launcher's rootful package and every signed Mach-O code page."""
import argparse
import hashlib
import io
from pathlib import Path
import plistlib
import struct
import subprocess
import tarfile

BINARIES = (
    'Library/MobileSubstrate/DynamicLibraries/OrbitLauncher.dylib',
    'Library/PreferenceBundles/OrbitPrefs.bundle/OrbitPrefs',
)


def verify_macho(data, name):
    magic, cpu, subtype, filetype, count, commands_size, flags, reserved = struct.unpack_from('<8I', data)
    assert magic == 0xFEEDFACF and cpu == 0x0100000C, f'{name}: expected thin arm64 Mach-O'
    assert filetype == 6, f'{name}: expected dynamically linked library'
    position = 32
    minimum = sdk = signature = None
    libraries = []
    for _ in range(count):
        command, size = struct.unpack_from('<II', data, position)
        assert size >= 8 and position + size <= 32 + commands_size
        if command == 0x25:  # LC_VERSION_MIN_IPHONEOS
            minimum, sdk = struct.unpack_from('<II', data, position + 8)
        elif command == 0x32:  # LC_BUILD_VERSION
            platform, minimum, sdk = struct.unpack_from('<III', data, position + 8)
            assert platform == 2, f'{name}: expected iOS device platform'
        elif command == 0x1D:  # LC_CODE_SIGNATURE
            signature = struct.unpack_from('<II', data, position + 8)
        elif command in (0xC, 0x18 | 0x80000000, 0x1F | 0x80000000):
            start, = struct.unpack_from('<I', data, position + 8)
            libraries.append(data[position+start:position+size].split(b'\0', 1)[0].decode())
        position += size
    assert minimum == 12 << 16, f'{name}: minimum OS must be 12.0'
    assert sdk == (12 << 16 | 4 << 8), f'{name}: expected iOS 12.4 SDK build'
    assert signature is not None, f'{name}: missing code signature'
    assert not any('/var/jb' in path for path in libraries), f'{name}: rootless dependency'
    offset, length = signature
    blob = data[offset:offset+length]
    blob_magic, blob_size, blob_count = struct.unpack_from('>III', blob)
    assert blob_magic == 0xFADE0CC0 and blob_size <= len(blob)
    directories = 0
    for entry in range(blob_count):
        slot, relative = struct.unpack_from('>II', blob, 12 + entry * 8)
        if slot != 0 and not 0x1000 <= slot < 0x1006:
            continue
        directory = blob[relative:]
        (cd_magic, cd_length, version, cd_flags, hash_offset, ident_offset,
         special_count, code_count, code_limit) = struct.unpack_from('>9I', directory)
        assert cd_magic == 0xFADE0C02 and cd_length <= len(directory)
        assert cd_flags & 2, f'{name}: expected ad-hoc signature flag'
        hash_size, hash_type, platform, page_power = struct.unpack_from('>4B', directory, 36)
        algorithm = {1: 'sha1', 2: 'sha256', 3: 'sha256', 4: 'sha384'}[hash_type]
        page_size = 1 << page_power
        assert code_limit == offset and code_count == (code_limit + page_size - 1) // page_size
        assert hash_offset + code_count * hash_size <= cd_length
        for page in range(code_count):
            page_data = data[page*page_size:min((page+1)*page_size, code_limit)]
            expected = directory[hash_offset+page*hash_size:hash_offset+(page+1)*hash_size]
            assert hashlib.new(algorithm, page_data).digest()[:hash_size] == expected, f'{name}: code page hash mismatch'
        directories += 1
    assert directories, f'{name}: no signed code directory'
    print(f'PASS: {name}: arm64, minimum iOS 12.0, SDK 12.4, {directories} ad-hoc code directory/directories verified')
    for library in libraries:
        print(f'  dependency: {library}')


def archive(deb, option):
    result = subprocess.run(['dpkg-deb', option, str(deb)], check=True, capture_output=True)
    return tarfile.open(fileobj=io.BytesIO(result.stdout), mode='r:*')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('deb', type=Path)
    args = parser.parse_args()
    deb = args.deb.resolve()
    info = subprocess.run(['dpkg-deb', '--field', str(deb)], check=True, capture_output=True, text=True).stdout
    assert 'Architecture: iphoneos-arm\n' in info
    assert 'Package: io.github.orbitlauncher\n' in info
    assert 'Version: 1.1.2\n' in info
    assert all(value in info for value in ('mobilesubstrate', 'preferenceloader', 'libactivator', 'firmware (>= 12.0)', 'firmware (<< 13.0)'))
    with archive(deb, '--ctrl-tarfile') as control:
        controls = {member.name.removeprefix('./'): member for member in control.getmembers()}
        for name in ('postinst', 'postrm'):
            member = controls[name]
            assert member.mode == 0o755 and member.uid == member.gid == 0
            assert control.extractfile(member).read().startswith(b'#!/bin/sh\n')
    with archive(deb, '--fsys-tarfile') as payload:
        members = {member.name.removeprefix('./'): member for member in payload.getmembers()}
        for name, member in members.items():
            assert '..' not in Path(name).parts and not name.startswith('/')
            assert 'var/jb' not in name and not member.mode & 0o002
            assert member.uid == member.gid == 0
        for name in BINARIES:
            verify_macho(payload.extractfile(members[name]).read(), name)
        for name in ('Library/PreferenceBundles/OrbitPrefs.bundle/Info.plist',
                     'Library/PreferenceLoader/Preferences/OrbitLauncher.plist'):
            plistlib.loads(payload.extractfile(members[name]).read())
        prefs_info=plistlib.loads(payload.extractfile(members['Library/PreferenceBundles/OrbitPrefs.bundle/Info.plist']).read())
        assert prefs_info['CFBundleDisplayName']=='Mac-Launcher'
        assert prefs_info['CFBundleShortVersionString']=='1.1.2'
        prefs_binary=payload.extractfile(members[BINARIES[1]]).read()
        assert b'OLColorController\0' in prefs_binary and b'OLColorWheel\0' in prefs_binary
        assert b'UIColorPickerViewController' not in prefs_binary, 'iOS 14 picker is unavailable on iOS 12'
        for suffix, size in (('',29),('@2x',58),('@3x',87)):
            name='Library/PreferenceBundles/OrbitPrefs.bundle/icon'+suffix+'.png'
            image=payload.extractfile(members[name]).read()
            assert image[:8]==b'\x89PNG\r\n\x1a\n'
            assert struct.unpack_from('>II',image,16)==(size,size)
        filter_name = 'Library/MobileSubstrate/DynamicLibraries/OrbitLauncher.plist'
        injection_filter = payload.extractfile(members[filter_name]).read()
        assert b'com.apple.springboard' in injection_filter
    print('PASS: package metadata, dependencies, rootful paths, ownership, permissions, control scripts and XML plists')
    print('SHA256:', hashlib.sha256(deb.read_bytes()).hexdigest())
    print('NOT TESTED: installation or runtime behavior on an actual iPod / Amethyst.')


if __name__ == '__main__':
    main()
