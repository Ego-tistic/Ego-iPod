# Mac-Launcher 1.1.2 validation

## Install interruption repair

Maintainer scripts no longer restart processes. Tests exercise real scripts with an inherited finish pipe, CLI execution, other lifecycle events, invalid descriptors, and stub restart commands. The GUI receives `finish:restart` after configure/remove. Direct CLI users respring after dpkg completes. Existing UI device checks below remain outstanding.

## Change coverage

- Save every changed opacity step and retry saving on release; explicitly enable
  interaction for the custom preference cell.
- Use the same explicit CFPreferences user/host scope for reads and writes.
- Preserve existing preferences, app selections, recents and Activator IDs.
- Remove the forced 100% opacity override. Reduce Transparency now disables blur
  while leaving the selected fill opacity in effect.
- Keep visual-effect view/ancestor alpha at 1. Use a paused property animator
  for intermediate blur; stop it when changing effect or destroying the view.
- Fade/slide the content panel on close, not the blur's ancestor view.
- Scale shadows to zero at zero opacity, alongside fill/rim/highlights.
- Offer Dark/Light/Custom Color, with a UIKit color wheel and HSB sliders. Use
  the custom color for both surfaces and dimming; choose text contrast from it.
- Replace remaining user-facing Orbit wording with Mac-Launcher. Internal IDs
  are compatibility identifiers, and the original license attribution remains.

## Host checks

See the accompanying build-verification.txt for actual command results. Theos,
Clang 11.1.2 and iOS 12.4 SDK compile and package verification do not establish
that the UI works correctly on the physical iPod. No device is attached here.

## Required device checks

1. Upgrade, let SpringBoard respring, then close/reopen Settings. Confirm all
   existing app choices, theme choice and Activator assignment remain intact.
2. Set opacity to 0%, 5%, 35%, 95%, 100%. Reopen the launcher after each change.
   Verify clear/solid endpoints and visible intermediate changes in drawer and
   dock. Reopen Settings and respring to check persistence. Interrupt a drag by
   opening the launcher, scrolling the page, pressing Home or switching apps.
3. Repeat with Reduce Transparency on/off, Reduce Motion on/off, light/dark
   themes and dock blur on/off. Dock blur off must remain off. At zero, shadows,
   highlights and fills disappear; app icons, text and controls remain usable.
4. Choose Custom Color, drag the wheel through primary hues and white center,
   adjust brightness to black/white/colored endpoints. Compare the preview and
   launcher hue. Check landscape Settings layout and scroll on the small screen.
5. Use VoiceOver's Hue/Saturation/Brightness sliders and opacity 5% increments.
   Check bright/dark wallpapers, search keyboard, tooltip contrast and reachability.
6. Test drawer search, dock scrolling/magnification, recent-five separation,
   long-press name display, launch/close behavior, Home gestures and lock safety.

## Research reference

Apple's UIVisualEffectView documentation warns against alpha below 1 on the
effect view or its ancestors. This update uses iOS 10+ UIViewPropertyAnimator
and iOS 11+ pausesOnCompletion; compile availability is checked with the 12.4 SDK.
https://developer.apple.com/documentation/uikit/uivisualeffectview/
