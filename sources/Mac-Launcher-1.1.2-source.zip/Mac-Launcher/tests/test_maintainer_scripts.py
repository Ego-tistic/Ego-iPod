"""Exercise actual scripts and the installer finish pipe without respringing."""
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]

@unittest.skipUnless(os.name=='posix','Tests inherited POSIX file descriptors')
class MaintainerScripts(unittest.TestCase):
    def run_script(self,name,argument,cydia=None,finish=False):
        with tempfile.TemporaryDirectory() as folder:
            log=Path(folder)/'unexpected-restart'
            for tool in ('sbreload','killall','launchctl'):
                stub=Path(folder)/tool
                stub.write_text('#!/bin/sh\necho invoked >> "'+str(log)+'"\n');stub.chmod(0o755)
            env=dict(os.environ,PATH=folder+':'+os.environ.get('PATH',''));env.pop('CYDIA',None)
            read,write=os.pipe()
            if finish:env['CYDIA']=str(write)+' 1'
            elif cydia is not None:env['CYDIA']=cydia
            try:
                result=subprocess.run(['/bin/sh',str(ROOT/'layout/DEBIAN'/name),argument],env=env,pass_fds=(write,),capture_output=True,text=True,timeout=5)
                os.close(write);write=None;payload=os.read(read,1024)
                self.assertEqual(result.returncode,0,result.stderr)
                self.assertFalse(log.exists(),'script restarted a process')
                return payload,result.stdout
            finally:
                if write is not None:os.close(write)
                os.close(read)
    def test_installer_receives_deferred_request(self):
        for name,argument in (('postinst','configure'),('postrm','remove')):
            self.assertEqual(self.run_script(name,argument,finish=True)[0],b'finish:restart\n')
    def test_cli_completes_without_restart(self):
        for name,argument in (('postinst','configure'),('postrm','remove')):
            payload,text=self.run_script(name,argument)
            self.assertEqual(payload,b'');self.assertIn('Respring after',text)
    def test_other_events_do_not_request_restart(self):
        for name,argument in (('postinst','abort-upgrade'),('postrm','upgrade'),('postrm','purge')):
            self.assertEqual(self.run_script(name,argument,finish=True)[0],b'')
    def test_bad_descriptor_cannot_break_dpkg(self):
        for value in ('bad 1','3;exit 9','999999 1'):
            self.assertEqual(self.run_script('postinst','configure',cydia=value)[0],b'')
