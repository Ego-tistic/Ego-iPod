# Mac-Launcher 1.1.2

A rootful arm64 iOS 12 launcher with a searchable app drawer and a scrolling,
magnifying Mac-style dock. Drawer and dock rise from the bottom. Long-press an
icon to see its name. The dock has a separate unlabeled section of up to five
recently used allowed apps, newest first, followed by the selected app catalog.
App selection affects only this launcher, not SpringBoard icons or their layout.

## Install interruption repair

Version 1.1.2 writes directly to the inherited installer file descriptor. The iPod has no `/dev/fd` filesystem; version 1.1.1 already stopped forced resprings but its finish request could not be delivered there. Direct descriptor duplication has now been checked using `/bin/sh` on this device.


The old scripts resprang SpringBoard while dpkg was still configuring the package. The new scripts send `finish:restart` to the GUI installer instead, allowing dpkg to finish first. Direct CLI installation does not restart processes; respring manually afterward. Pending Mac-Launcher configurations were observed on the iPod for versions 1.0.0 and 1.1.0; the scripts are a plausible contributor, not a proven exclusive cause.

## Appearance

Settings → Mac-Launcher → Theme offers **Dark**, **Light**, and **Custom Color**.
The Custom Color Wheel uses an iOS 12-compatible UIKit hue/saturation wheel,
with Hue, Saturation, and Brightness sliders, a hex preview, and accessible
slider equivalents. Choosing a color activates Custom Color. Existing Dark Theme
preferences migrate to the matching theme. App choices and Activator assignments
are preserved; internal package, bundle, and preference identifiers intentionally
retain their original names for upgrade compatibility.

Surface Opacity stays in 5% increments from 0% (clear) through 100% (solid).
Each changed step is saved during dragging as well as on release, so an
interrupted drag does not discard it. Icons and text remain opaque. Surface
fill, highlights, border, shadow, search button, and backdrop reflect the value.
Reduce Transparency disables blur but no longer silently forces the slider to
100%. Blur Behind Dock remains a separate switch and defaults off.

Blur intensity now uses a paused UIViewPropertyAnimator rather than lowering
UIVisualEffectView alpha, which Apple documents as producing incorrect effects:
https://developer.apple.com/documentation/uikit/uivisualeffectview/
Close/reopen Mac-Launcher after changing appearance. The package manager offers a respring after upgrading;
close and reopen Settings afterward to load the updated preference bundle.

These are glass-inspired surfaces implemented with iOS 12 APIs, not the iOS 26
Liquid Glass framework. Appearance and device behavior still require iPod testing.

## Build and installation

Install Theos with its recursive submodules, an arm64 iOS compiler, the iOS 12.4
SDK, and Activator headers/link stubs. From this directory:

```sh
export THEOS=/path/to/theos
sh tools/build.sh TARGET=iphone:clang:12.4:12.0
python3 tools/verify_deb.py packages/io.github.orbitlauncher_1.1.2_iphoneos-arm.deb
```

Build as a normal user. `ARCHS=arm64`, deployment target 12.0, default rootful
scheme only; Debian package architecture is `iphoneos-arm`. Runtime dependencies:
mobilesubstrate, preferenceloader, libactivator, and iOS >=12.0,<13.0.
Rootful payload paths retain OrbitLauncher.dylib and OrbitPrefs.bundle so upgrades
replace the existing files. The display name throughout the UI is Mac-Launcher.

Add https://ego-tistic.github.io/Ego-iPod/ to Cydia/Zebra, refresh sources, and
upgrade Mac-Launcher. Alternatively install the built .deb through your package
manager or `dpkg -i` as root. The install/removal scripts request a respring from the package manager after dpkg completes. CLI installs print a manual respring reminder.
Remove using the package manager or `dpkg -r io.github.orbitlauncher`; saved
preferences remain. No Bluetooth daemon modifications are made by this tweak.

## Physical Home triple press

In Activator, assign Home Button → Triple Press to Mac-Launcher under Launchers,
separately for At Home Screen and In Application. Do not assign on the lock
screen. A second triple press, backdrop tap, close control, or Home dismisses it.

Check Settings → General → Accessibility → Accessibility Shortcut for a conflict.
Keep any shortcut you rely on and choose a different Activator gesture instead.
Mac-Launcher does not change either assignment automatically. Single/double/long
Home behavior remains with iOS and Activator. Lock transitions close the launcher.

## Checks and limits

Build/package verification checks the two arm64 binaries, iOS 12.0 minimum,
iOS 12.4 SDK, ad-hoc code-page signatures, rootful paths, dependencies and modes.
Native opacity tests check quantization/clamping; repo tests check indexes/hashes.
These checks do not simulate Preferences touch handling, compositor output,
Activator delivery, Amethyst injection, or real app launching. See VALIDATION.md.
For APT publishing/index instructions see REPO.md. Source is MIT licensed.
