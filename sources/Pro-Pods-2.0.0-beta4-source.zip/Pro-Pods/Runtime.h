#pragma once
#include <CoreFoundation/CoreFoundation.h>
#include "Policy.h"
#define PP_DOMAIN CFSTR("com.propods.tweak")
#define PP_CHANGED "com.propods.tweak.changed"
#define PP_REQUEST "com.propods.tweak.status-request"
#define PP_STATUS "/var/tmp/pro-pods-status.plist"
#define PP_LOG "/var/tmp/pro-pods-status.log"
#define PP_DISABLED "/var/lib/pro-pods/disabled"
CFDictionaryRef PPReadDictionary(const char *path);
unsigned PPLoadSettings(void);
void PPLog(const char *message);
