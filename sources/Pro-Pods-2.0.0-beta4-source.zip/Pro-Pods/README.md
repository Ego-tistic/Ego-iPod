> Superseded analysis: see [BLUETOOTHD-REVIEW.md](BLUETOOTHD-REVIEW.md). The old second getter is a supported-features version, not a product ID. Beta2 has no mapping hooks.

# Pro-Pods 2.0.0 beta2 — recovery update

The device report shows repeatedly changing bluetoothd PIDs (often ~10 seconds apart), with zero successful mappings. Older logs contain implausible values, including values consistent with UTF-16 text. This makes output interpretation/ABI validation a priority, but does not establish the crash mechanism. A function hash identifies code, not its C signature. Mapping-policy unit tests did not validate those signatures.

**All Bluetooth mapping hooks are removed in this binary.** It retains only bounded logging and fresh-response status. No switch can enable interception. Install this recovery update OR uninstall Pro-Pods, then restart and re-jailbreak to unload earlier hooks. This is NOT an audio compatibility fix and does not promise that native iOS 12 pairing will work.

Beta1 and older diagnostic builds are withdrawn from the APT index; their files remain solely to avoid breaking cached package URLs. Do not reinstall them. The live repo is updated for every ready revision as requested.

Next evidence: the matching /usr/sbin/bluetoothd binary, and a fresh bluetoothd crash report. No new getter signature or return-value convention will be assumed from the old log alone.

## Earlier beta1 record (superseded)

# Pro-Pods 2.0.0 beta 1

A reworked **experimental legacy-audio compatibility tweak** for rootful iPod touch 6 (iPod7,1), iOS 12.5.8. Built after reports that AirPods Pro 3 and AirPods Max connect and then disconnect after a few seconds. It is **not yet a confirmed fix** for that symptom.

## What changed

- Default Legacy Audio mode reports Pro 3 (8231/8232) and Max Lightning/USB-C (8202/8223) as AirPods 2 (8207), an identity supported from iOS 12.2. This replaces the old default Pro 3 → Pro 1 (8206) mapping, whose full setup requires iOS 13.2. This is a plausible compatibility hypothesis, not proof of the root cause.
- Settings → Pro-Pods: live enable/disable, separate Pro 3 and Max switches, second-ID-path switch, old-identity comparison mode, bounded diagnostics and opt-in experimental Max 2.
- Runtime status asks the injected daemon for a fresh nonce-tagged response. A stale file is not reported as proof of activation. Reports show hook state, process PID/start time, mapping counts and the last mapped numeric ID.
- Copy Diagnostic Report makes the next device test practical. PID changes identify a daemon restart, not necessarily a crash; a crash report is needed to establish its cause. No live headphone connection/audio state is inferred from mappings or process counts.
- Root recovery helper: `pro-podsctl disable`, `enable`, `status`. Live bypass works after this version is loaded into bluetoothd. Disabling bypasses mapping; hooks remain installed until daemon restart.
- No arbitrary product-ID overrides. Max 2 (8237) is off by default. The HID accessor has no vendor output: its optional mapping is restricted to the five recognized IDs, while the multi-field accessor requires source 1 / Apple vendor 0x004c.
- No modifications to device-object memory, pairing databases, headphones firmware, Bluetooth volume/capability flags, packet parser, or global log functions. No forced daemon kill, automatic reboot or privileged automatic recovery service.

## Install and test

1. Install `Pro-Pods_2.0.0-beta1.deb` over Pro-Pods through your existing local package installer. It upgrades package ID `com.propods.tweak`; do not install alongside PodsGrant. PreferenceLoader and a compatible MobileSubstrate provider are dependencies.
2. **Restart the iPod and re-jailbreak.** Respring alone does not replace the already-running bluetoothd hooks. Do this after every package install/upgrade/removal affecting the daemon. Reopen Settings to load the new preference bundle.
3. Open Settings → Pro-Pods → Show Runtime Status. Expect both verified hooks installed and Legacy Audio. A recovery disable marker, an unreadable preference file, or an unsupported binary can prevent mapping even when the UI switch was enabled.
4. Pair one headphone set at a time and play a downloaded/local track for at least five minutes. On Pro 3, double-tap the case front until its light flashes white, then select it in Settings → Bluetooth. On Max, use the listening-mode button for pairing. Keep the other set disconnected while testing.
5. If it drops, check status again. A changed PID/start time indicates a process restart; without it the issue may be a connection/audio failure, but status cannot identify the cause. Copy Diagnostic Report and inspect a fresh bluetoothd crash report from the normal CrashReporter location if one exists. Reports from the old build, an old PID or a pre-install test do not validate this build.
6. Compare mapping disabled versus Legacy Audio using the Enabled switch, disconnect/reconnect, and replay the same track. Old Pro Identity is a separate comparison mode, not an added feature. If one path causes instability, disable Use Second ID Path and retest; do not combine it with PodsGrant.

## Recovery

Use Settings → Pro-Pods → Enabled off for live bypass after loading the new daemon. A root terminal can set the stronger recovery override with `pro-podsctl disable`; `enable` removes that override but still respects Settings. The helper does not restart bluetoothd or delete pairings. If the daemon/system is unresponsive, use the jailbreak's documented no-tweak mode and uninstall Pro-Pods, then restart/re-jailbreak. Existing legacy disable markers are honored. Arbitrary overrides from the old Max experiment are deliberately ignored.

## Build

Requires Theos, rootful arm64 toolchain and the patched iPhoneOS 12.4 SDK. Build as a normal user:

```sh
export THEOS=/path/to/theos
find layout prefs/Resources -type d -exec chmod 755 {} +
find layout prefs/Resources -type f -exec chmod 644 {} +
make package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME=
```

The resulting `.deb` is under packages/. The daemon component links CoreFoundation/Substrate only, not UIKit. The preference bundle contains UIKit separately. All three binaries are explicitly ad-hoc signed. The installer does not automatically restart Bluetooth or your device.

Host policy tests:

```sh
cc -std=c11 -Wall -Wextra -Werror -fsanitize=address,undefined -I. tests/test_policy.c -o /tmp/pro-pods-policy-test
/tmp/pro-pods-policy-test
python3 tools/verify_package.py packages/com.propods.tweak_2.0.0~beta1_iphoneos-arm.deb
```

See RESEARCH.md and VALIDATION.md. The exact inherited UUID and both complete function hashes in VerifiedProfile.h are checked before hooking. No permissive scanner fallback is used; the old read-only inspection/address-finder tools are research aids only. The supplied bluetoothd binary from the earlier investigation was not available in this session, so its original analysis was not repeated. Changing identity cannot supply iOS 26 features, audio codecs, hardware support or Apple-account services. Firmware compatibility, connection stability, Settings behavior and daemon sandbox access must be checked on the real iPod. This beta has not been promoted over the live Ego-iPod repo package.

MIT-licensed adaptation. Original PodsGrant copyright (c) 2023 Ruphane and Pro-Pods adaptation copyright retained in LICENSE.
