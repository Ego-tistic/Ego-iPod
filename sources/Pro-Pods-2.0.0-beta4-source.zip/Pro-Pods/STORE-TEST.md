# Superseded experiment

The earlier 1.1.0~maxdiag1 store experiment is superseded by the 2.0 beta in README.md. Max 2 is now off by default. Do not follow historical arbitrary product-ID override instructions: that parser/helper has been removed from the active implementation. Git history retains the old source for comparison.
