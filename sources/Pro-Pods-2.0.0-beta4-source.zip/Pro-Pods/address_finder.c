/* Signature scanner adapted from PodsGrant by Ruphane, MIT licensed. */
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static const uint32_t first[] = {
    0xffc003e0,0x39400000, 0xff000000,0x34000000,
    0xffc003e0,0xb9400000, 0xffc003e0,0xb9000020,
    0xffc003e0,0xb9400000, 0xffc003e0,0xb9000040,
    0xffc003e0,0xb9400000, 0xffc003e0,0xb9000060,
    0xffc003e0,0xb9400000, 0xffc003e0,0xb9000080
};
static const uint32_t second[] = {
    0xffc003e0,0xb9400000, 0xfffffc1f,0x7101301f,
    0xff00001f,0x54000001, 0xffc00000,0xb9400000,
    0xffffffe0,0x12840020, 0xff000000,0x0b000000,
    0xfffffc1f,0x7100441f
};

static int find(uint32_t *out, const uint32_t *pattern, size_t bytes, FILE *f) {
    uint32_t value; size_t matched = 0; int count = 0;
    fseek(f, 0, SEEK_SET);
    while (fread(&value, 1, 4, f) == 4) {
        if ((pattern[matched * 2] & value) == pattern[matched * 2 + 1]) {
            if (++matched == bytes / (2 * sizeof(uint32_t))) {
                out[count++] = (uint32_t)ftell(f) - (uint32_t)(bytes / 2);
                matched = 0;
                if (count == 16) break;
            }
        } else {
            /* Retry every aligned start, including overlapping candidates. */
            if (matched && fseek(f, -(long)(matched * 4), SEEK_CUR) != 0) return 0;
            matched = 0;
        }
    }
    return count;
}

int PP_find_addresses(uint64_t addresses[2], uint32_t *product_id_offset) {
    FILE *binary = fopen("/usr/sbin/bluetoothd", "rb");
    if (!binary) return 0;
    /* Upstream's file-offset arithmetic requires a thin ARM64 executable
       whose __TEXT starts at file offset 0 and VM address 0x100000000. */
    uint32_t header[8];
    if (fread(header, sizeof(header), 1, binary) != 1 ||
        header[0] != 0xfeedfacf || header[1] != 0x0100000c ||
        header[2] != 0 || header[3] != 2 || header[4] > 1024) {
        fclose(binary); return 0;
    }
    int text_ok = 0;
    uint64_t command_end = sizeof(header) + (uint64_t)header[5];
    for (uint32_t i = 0; i < header[4]; ++i) {
        long start = ftell(binary);
        uint32_t command[2];
        if (start < 0 || fread(command, sizeof(command), 1, binary) != 1 ||
            command[1] < 8 || (uint64_t)start + command[1] > command_end) break;
        if (command[0] == 0x19 && command[1] >= 72) {
            char name[16]; uint64_t segment[4];
            if (fread(name, sizeof(name), 1, binary) != 1 ||
                fread(segment, sizeof(segment), 1, binary) != 1) break;
            if (memcmp(name, "__TEXT\0", 7) == 0 &&
                segment[0] == 0x100000000ULL && segment[2] == 0) text_ok = 1;
        }
        if (fseek(binary, start + command[1], SEEK_SET) != 0) break;
    }
    if (!text_ok) { fclose(binary); return 0; }
    uint32_t result[16];
    int a = find(result, first, sizeof(first), binary);
    if (a != 1) { fclose(binary); return 0; }
    uint32_t instruction;
    fseek(binary, result[0] + 6 * 4, SEEK_SET);
    if (fread(&instruction, 1, 4, binary) != 4) { fclose(binary); return 0; }
    *product_id_offset = ((instruction >> 10) & 0xfff) << 2;
    addresses[0] = (uint64_t)result[0] + 0x100000000ULL;
    int b = find(result, second, sizeof(second), binary);
    if (b != 1 || result[0] < 4) { fclose(binary); return 0; }
    fseek(binary, result[0] - 4, SEEK_SET);
    if (fread(&instruction, 1, 4, binary) != 4) { fclose(binary); return 0; }
    if ((instruction & 0xffe0ffe0) == 0xaa0003e0) result[0] -= 4;
    addresses[1] = (uint64_t)result[0] + 0x100000000ULL;
    fclose(binary);
    return 1;
}
