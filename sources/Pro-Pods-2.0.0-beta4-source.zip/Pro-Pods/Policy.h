#pragma once
#include <stdint.h>
#include <stdbool.h>
enum { PP_ENABLED=1, PP_PRO3=2, PP_MAX=4, PP_HID=8, PP_TRACE=16, PP_PRO_IDENTITY=32, PP_MAX2=64 };
#define PP_DEFAULT (PP_ENABLED|PP_PRO3|PP_MAX|PP_HID)
static inline bool PPMap(uint32_t *product, unsigned flags) {
    if (!product || !(flags&PP_ENABLED)) return false;
    uint32_t id=*product;
    bool pro=(flags&PP_PRO3) && (id==8231 || id==8232);
    bool max=((flags&PP_MAX) && (id==8202 || id==8223)) || ((flags&PP_MAX2) && id==8237);
    if (!pro && !max) return false;
    *product=(flags&PP_PRO_IDENTITY) ? (pro ? 8206 : 8194) : 8207;
    return true;
}
static inline bool PPMapDevice(uint32_t success,const uint32_t *source,const uint32_t *vendor,uint32_t *product,unsigned flags) {
    return success && source && vendor && *source==1 && *vendor==0x4c && PPMap(product,flags);
}
static inline bool PPMapHID(uint32_t success,uint32_t *product,unsigned flags) {
    return success && (flags&PP_HID) && PPMap(product,flags);
}
