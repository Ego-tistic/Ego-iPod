#include "Runtime.h"
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <time.h>

CFDictionaryRef PPReadDictionary(const char *path) {
    int fd=open(path,O_RDONLY|O_NOFOLLOW|O_NONBLOCK); if(fd<0) return NULL;
    struct stat st;
    if(fstat(fd,&st) || !S_ISREG(st.st_mode) || (st.st_uid!=0 && st.st_uid!=501) ||
       st.st_nlink!=1 || (st.st_mode&0022) || st.st_size<1 || st.st_size>16384) {close(fd);return NULL;}
    uint8_t bytes[16384]; ssize_t used=0;
    while(used<st.st_size) {ssize_t n=read(fd,bytes+used,(size_t)(st.st_size-used));if(n<0 && errno==EINTR)continue;if(n<=0)break;used+=n;}
    close(fd);if(used!=st.st_size) return NULL;
    CFDataRef data=CFDataCreate(NULL,bytes,used);
    if(!data)return NULL;
    CFPropertyListRef plist=CFPropertyListCreateWithData(NULL,data,kCFPropertyListImmutable,NULL,NULL);CFRelease(data);
    if(!plist)return NULL;
    if(CFGetTypeID(plist)!=CFDictionaryGetTypeID()){CFRelease(plist);return NULL;}
    return (CFDictionaryRef)plist;
}
static bool setting(CFDictionaryRef d,CFStringRef key,bool fallback) {
    CFTypeRef v=CFDictionaryGetValue(d,key);
    return v && CFGetTypeID(v)==CFBooleanGetTypeID() ? CFBooleanGetValue(v) : fallback;
}
unsigned PPLoadSettings(void) {
    const char *path="/var/mobile/Library/Preferences/com.propods.tweak.plist";
    unsigned flags=PP_DEFAULT;
    CFDictionaryRef d=PPReadDictionary(path);
    if(d) {
        flags=0;
        if(setting(d,CFSTR("enabled"),true))flags|=PP_ENABLED;
        if(setting(d,CFSTR("pro3"),true))flags|=PP_PRO3;
        if(setting(d,CFSTR("max"),true))flags|=PP_MAX;
        if(setting(d,CFSTR("hid"),true))flags|=PP_HID;
        if(setting(d,CFSTR("diagnostics"),false))flags|=PP_TRACE;
        if(setting(d,CFSTR("legacyPro"),false))flags|=PP_PRO_IDENTITY;
        if(setting(d,CFSTR("max2"),false))flags|=PP_MAX2;
        CFRelease(d);
    } else if(access(path,F_OK)==0) {PPLog("invalid/unreadable preference file; experiment disabled");flags=0;}
    if(access(PP_DISABLED,F_OK)==0 || access("/var/mobile/Library/Preferences/com.propods.disabled",F_OK)==0)flags&=~PP_ENABLED;
    return flags;
}
void PPLog(const char *message) {
    static pthread_mutex_t lock=PTHREAD_MUTEX_INITIALIZER;
    pthread_mutex_lock(&lock);
    int fd=open(PP_LOG,O_WRONLY|O_APPEND|O_CREAT|O_NOFOLLOW|O_NONBLOCK,0644);
    if(fd>=0) {
        struct stat st;
        if(!fstat(fd,&st) && S_ISREG(st.st_mode) && st.st_uid==geteuid() && st.st_nlink==1 && !(st.st_mode&0022)) {
            if(st.st_size>65000) (void)ftruncate(fd,0);
            char line[320];int n=snprintf(line,sizeof(line),"Pro-Pods 2.0 beta4 t=%lld pid=%d %s\n",(long long)time(NULL),getpid(),message);
            if(n>0 && (size_t)n<sizeof(line))(void)write(fd,line,(size_t)n);
        }
        close(fd);
    }
    pthread_mutex_unlock(&lock);
}
