# Pro-Pods 2.0.0 beta2 — recovery update

The device report shows repeatedly changing bluetoothd PIDs (often ~10 seconds apart), with zero successful mappings. Older logs contain implausible values, including values consistent with UTF-16 text. This makes output interpretation/ABI validation a priority, but does not establish the crash mechanism. A function hash identifies code, not its C signature. Mapping-policy unit tests did not validate those signatures.

**All Bluetooth mapping hooks are removed in this binary.** It retains only bounded logging and fresh-response status. No switch can enable interception. Install this recovery update OR uninstall Pro-Pods, then restart and re-jailbreak to unload earlier hooks. This is NOT an audio compatibility fix and does not promise that native iOS 12 pairing will work.

Beta1 and older diagnostic builds are withdrawn from the APT index; their files remain solely to avoid breaking cached package URLs. Do not reinstall them. The live repo is updated for every ready revision as requested.

Next evidence: the matching /usr/sbin/bluetoothd binary, and a fresh bluetoothd crash report. No new getter signature or return-value convention will be assumed from the old log alone.

## Earlier beta1 record (superseded)

# Validation record

## Completed on the build host

- Private source cloned at 325d002 and reworked on local branch rework/ios12-legacy-audio. Public Ego-iPod repo and Mac-Launcher package remain unchanged by this task.
- Policy exhaustively tested for 65,536 product IDs × 128 flag combinations (8,388,608 combinations), plus failed-return/null/vendor/source/high-bit guards and output canaries. Compiled with AddressSanitizer/UndefinedBehaviorSanitizer; passed.
- Compiled and linked daemon tweak, root recovery tool and Preferences bundle for arm64, deployment iOS 12.0, with the iOS 12.4 SDK and Theos/Clang 11.1.0 used for Mac-Launcher. Ad-hoc signing and rootful package assembly completed.
- Package verifier checks metadata, dependency/version bounds, rootful paths/ownership/permissions, all three Mach-O CPU/platform/minimum OS/SDK fields, signed code-page hashes and preference XML. See delivered validation-results.txt for the actual verifier result.
- Inherited VerifiedProfile.h is unchanged; both full function hashes and the UUID are required before runtime interception. Raw system binary was unavailable for independent reinspection in this session.

## Pending actual-device checks

1. Upgrade on iPod7,1/iOS 12.5.8, restart/re-jailbreak, reopen Settings. Confirm fresh Runtime Status and both hook gates. Unsupported images must remain untouched. Confirm daemon sandbox permits writing status/log files and receiving the two Darwin notification names.
2. Settings CFPreferences changes must reach the root daemon. Confirm enabled bypass, separate Pro/Max switches, second path bypass and old-identity comparison. No automatic daemon restart is promised.
3. Pro 3 and each available Max model: pair separately, play local audio for five minutes, both channels, volume/buttons, pause/resume, sleep/wake and reconnect. Compare with mapping disabled and the old identity. Record exact model/firmware and the test's process PID/start time.
4. On a drop, compare fresh reports. New PID means process restart/relaunch; check a current crash report to distinguish crash from other restarts. Unchanged PID does not prove an accessory firmware problem. Counters are getter observations, not active connection indicators.
5. Long-running behavior, log-size cap, privacy of copied report, live notification handshake, concurrent getter/config changes and an unavailable/stale daemon status need device validation.
6. Root-only recovery helper, legacy disable marker, no-tweak-mode removal, reboot/rejailbreak and old beta upgrades must be checked on the actual bootstrap. The CLI does not delete Bluetooth databases, kill the daemon or reset headphones.

No claim of stable pairing, audio, modern feature support or a confirmed disconnect fix follows from host test success. The deliverable is a compiled beta for private device testing, not a public automatic upgrade.
