#include "Policy.h"
#include <assert.h>
#include <stddef.h>
#include <stdio.h>
int main(void) {
    uint32_t source=1,vendor=0x4c;
    for(unsigned flags=0;flags<128;flags++) {
        for(uint32_t id=0;id<=UINT16_MAX;id++) {
            struct {uint32_t left,id,right;} out={0x11223344,id,0x88776655};
            bool eligible=((flags&PP_PRO3) && (id==8231 || id==8232)) ||
                ((flags&PP_MAX) && (id==8202 || id==8223)) || ((flags&PP_MAX2) && id==8237);
            bool expected=(flags&PP_ENABLED) && eligible;
            bool result=PPMapDevice(1,&source,&vendor,&out.id,flags);
            assert(result==expected);
            assert(out.left==0x11223344 && out.right==0x88776655);
            if(!expected)assert(out.id==id);
            else if(!(flags&PP_PRO_IDENTITY))assert(out.id==8207);
            else assert(out.id==((id==8231 || id==8232) ? 8206 : 8194));
            uint32_t hid=id;
            assert(PPMapHID(1,&hid,flags)==(expected && (flags&PP_HID)));
            if(!(flags&PP_HID))assert(hid==id);
        }
    }
    uint32_t id=8231;
    assert(!PPMapDevice(0,&source,&vendor,&id,PP_DEFAULT) && id==8231);
    assert(!PPMapDevice(1,NULL,&vendor,&id,PP_DEFAULT));
    assert(!PPMapDevice(1,&source,NULL,&id,PP_DEFAULT));
    assert(!PPMapDevice(1,&source,&vendor,NULL,PP_DEFAULT));
    vendor=0x1234;assert(!PPMapDevice(1,&source,&vendor,&id,PP_DEFAULT) && id==8231);
    vendor=0x4c;source=2;assert(!PPMapDevice(1,&source,&vendor,&id,PP_DEFAULT) && id==8231);
    id=0x10002027;assert(!PPMap(&id,PP_DEFAULT) && id==0x10002027);
    id=8237;assert(!PPMap(&id,PP_DEFAULT) && id==8237);
    assert(!PPMapHID(0,&id,127) && id==8237);
    assert(!PPMapHID(1,NULL,127));
    puts("PASS: 8,388,608 product/policy combinations; HID gating, vendor/source/failure/null/high-bit guards, untouched output canaries and Max2 opt-in.");
    return 0;
}
