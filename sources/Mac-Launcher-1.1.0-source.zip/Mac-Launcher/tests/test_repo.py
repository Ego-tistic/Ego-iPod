import bz2
from datetime import datetime, timezone
import gzip
import hashlib
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
import make_repo


class RepoTests(unittest.TestCase):
    def test_control_continuations_and_rejection(self):
        fields = make_repo.parse_control("Package: test\nVersion: 1\nArchitecture: iphoneos-arm\nDescription: Short\n Long\n .\n Last\n")
        self.assertEqual(fields["Description"], "Short\n Long\n .\n Last")
        with self.assertRaises(ValueError):
            make_repo.parse_control("Package: a\nPackage: b\n")
        with self.assertRaises(ValueError):
            make_repo.parse_control(" orphan\n")

    def test_indexes_roundtrip_and_all_release_hashes(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            records = [{"Package": "test", "Version": "1", "Architecture": "iphoneos-arm", "Description": "App\n More"}]
            now = datetime(2026, 11, 4, tzinfo=timezone.utc)
            make_repo.write_indexes(root, records, "Test", now)
            expected = (root / "Packages").read_bytes()
            self.assertEqual(gzip.decompress((root / "Packages.gz").read_bytes()), expected)
            self.assertEqual(bz2.decompress((root / "Packages.bz2").read_bytes()), expected)
            algorithm = None
            for line in (root / "Release").read_text().splitlines():
                if line in ("MD5Sum:", "SHA256:", "SHA512:"):
                    algorithm = {"MD5Sum:": "md5", "SHA256:": "sha256", "SHA512:": "sha512"}[line]
                elif line.startswith(" "):
                    digest, size, name = line.split()
                    data = (root / name).read_bytes()
                    self.assertEqual(int(size), len(data))
                    self.assertEqual(digest, hashlib.new(algorithm, data).hexdigest())
            before = (root / "Packages.gz").read_bytes()
            make_repo.write_indexes(root, records, "Test", now)
            self.assertEqual((root / "Packages.gz").read_bytes(), before)

    def test_package_metadata_and_hashes(self):
        # Fake dpkg output tests serialization only; this is not a compiled deb test.
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "debs").mkdir()
            deb = root / "debs" / "test_1_iphoneos-arm.deb"
            deb.write_bytes(b"fixture")
            output = "Package: test\nVersion: 1\nArchitecture: iphoneos-arm\nDescription: Test\nFilename: old\n"
            with patch.object(make_repo.subprocess, "run") as run:
                run.return_value.stdout = output
                record = make_repo.package_record(root, deb)
            self.assertEqual(record["Filename"], "./debs/test_1_iphoneos-arm.deb")
            self.assertEqual(record["Size"], "7")
            self.assertEqual(record["SHA256"], hashlib.sha256(b"fixture").hexdigest())
            with patch.object(make_repo.subprocess, "run") as run:
                run.return_value.stdout = output.replace("iphoneos-arm", "iphoneos-arm64")
                with self.assertRaises(ValueError):
                    make_repo.package_record(root, deb)

    def test_release_label_cannot_inject_fields(self):
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(ValueError):
                make_repo.write_indexes(Path(folder), [], "Bad\nField: injected")


if __name__ == "__main__":
    unittest.main()
