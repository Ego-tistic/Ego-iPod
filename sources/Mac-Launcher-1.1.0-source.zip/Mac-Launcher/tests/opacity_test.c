#include "../Opacity.h"
#include <assert.h>
int main(void) {
    for (int i=0;i<=100;i+=5) assert(OLSteppedOpacity(i)==i);
    assert(OLSteppedOpacity(32.49)==30);
    assert(OLSteppedOpacity(32.5)==35);
    assert(OLSteppedOpacity(-20)==0);
    assert(OLSteppedOpacity(200)==100);
    assert(OLSteppedOpacity(NAN)==35);
    assert(OLSteppedOpacity(INFINITY)==35);
    for (int i=-1000;i<=2000;i++) {
        double x=OLSteppedOpacity(i/10.0);
        assert(x>=0 && x<=100 && fmod(x,5)==0);
    }
    return 0;
}
