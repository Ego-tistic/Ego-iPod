#import <UIKit/UIKit.h>

#ifdef __cplusplus
extern "C" {
#endif
extern NSString * const OLDomain;
extern CFStringRef const OLChanged;
NSDictionary *OLSettings(void);
BOOL OLWriteSetting(NSString *key, id value);
BOOL OLWriteSettings(NSDictionary *values);
UIColor *OLSurfaceColor(NSDictionary *settings);
BOOL OLUsesLightText(UIColor *color);
NSArray<NSDictionary *> *OLApplications(void);
NSArray<NSDictionary *> *OLFilter(NSArray<NSDictionary *> *apps, NSString *query);
UIImage *OLIcon(NSString *identifier);
BOOL OLOpen(NSString *identifier);
void OLRecordRecent(NSString *identifier);
void OLCaptureFrontApp(void);
#ifdef __cplusplus
}
#endif

@interface UIApplication (OLForeground)
- (id)_accessibilityFrontMostApplication;
@end
@interface NSObject (OLBundleIdentifier)
- (NSString *)bundleIdentifier;
@end

// Minimal private declarations; look up classes at runtime, never link private symbols.
@interface LSApplicationWorkspace : NSObject
+ (instancetype)defaultWorkspace;
- (NSArray *)allApplications;
- (BOOL)openApplicationWithBundleID:(NSString *)identifier;
@end
@interface LSApplicationProxy : NSObject
- (NSString *)applicationIdentifier;
- (NSString *)localizedName;
- (NSString *)applicationType;
- (NSArray *)appTags;
@end
@interface UIImage (OLPrivate)
+ (UIImage *)_applicationIconImageForBundleIdentifier:(NSString *)identifier format:(int)format scale:(CGFloat)scale;
@end
