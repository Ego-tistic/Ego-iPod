# Local APT staging and publishing

This project uses a **flat** repo, compatible with a source line such as `deb https://YOUR-HOST/YOUR-PATH/ ./`. Replace that example only when preparing your actual hosting configuration. `./` is the distribution; no component is appended. This file does not authorize any upload or push.

## Existing repo first

If you already have a repo, use a separate local checkout or staging copy of its **complete contents**. Keep all existing packages and their metadata. If it already uses `dists/`, `pool/`, apt-ftparchive, or its own generator, add this `.deb` through that pipeline instead of replacing the layout. This project's helper scans only `debs/`; it must not overwrite an index covering packages in other directories. Do not run it directly on a live hosted directory.

## Create a new flat staging copy

After compiling and privately testing the package:

```sh
mkdir -p repo-stage/debs
cp packages/your-built-package.deb repo-stage/debs/
python3 tools/make_repo.py repo-stage --label 'My iOS 12 Repo'
```

Replace the package path with your actual artifact. The generator requires Python 3.9+ and `dpkg-deb` on the host. On Debian/Ubuntu, `dpkg-deb` ships with dpkg. On macOS install a suitable dpkg tool or generate the repo on Linux/WSL. The included empty `repo/` was generated with `--allow-empty`; that flag is for a scaffold only.

Result:

```text
repo-stage/
  debs/your-built-package.deb
  Packages
  Packages.gz
  Packages.bz2
  Release
```

`Packages` contains real `dpkg-deb --field` metadata, relative `Filename`, byte Size, and package MD5/SHA256/SHA512. `Release` includes Origin, Label, Suite, Codename, Architectures, UTC Date and MD5/SHA256/SHA512 hashes and lengths for all three index variants. MD5 is included for legacy compatibility; SHA256/SHA512 are included as well. Gzip has a deterministic timestamp. Rootless architecture, duplicate package/version/architecture tuples, path traversal, unsafe filename characters and stale signatures are rejected. Multiple different versions may coexist. If removing an old package, regenerate the indexes before publication.

The helper does **not** validate the actual Mach-O architecture/deployment target, test device functionality, or sign/upload anything. Check the `.deb` itself as described in README.md. Keep source/MIT license available beside your public release, for example in a linked source repository.

## Optional repo signing

Use your repo's existing key and existing client trust setup. Never rotate trust or generate a replacement key as part of a routine package update. After index generation, in your local staging copy:

```sh
gpg --local-user YOUR_EXISTING_KEY_ID --armor --detach-sign --output repo-stage/Release.gpg repo-stage/Release
gpg --local-user YOUR_EXISTING_KEY_ID --clearsign --output repo-stage/InRelease repo-stage/Release
gpg --verify repo-stage/Release.gpg repo-stage/Release
gpg --verify repo-stage/InRelease
```

An existing `InRelease` or `Release.gpg` causes the generator to refuse regeneration, because those signatures would become stale. For the next update, generate fresh indexes in a fresh staging copy and then sign again. Unsigned personal repos are common on older jailbreak clients, but verification/trust behavior varies by installed APT and package manager. Publishing an unsigned Release alone does not make it authenticated; do not globally disable APT authentication to solve a trust error. Distribute/import a public key through your existing supported trust process where available, and never distribute a private key.

## Verify and publish only after approval

1. Compare staged `Packages` against the old repo so other packages are preserved.
2. Decompress both compressed indexes and confirm they match `Packages`; verify Release hashes and all package file hashes.
3. Confirm every `Filename: ./debs/...` exists at the corresponding path.
4. Review label, date, version, dependency metadata and any signing files.
5. Get approval for the concrete staged diff and destination before pushing/uploading. There is no publishing script in this project.
6. Publish the complete staged release via your host's atomic deployment/version mechanism when possible. Keep old package URLs available while clients may still cache the old index. Avoid overwriting a `.deb` at the same URL with different bytes.
7. Serve `.deb`, `Packages`, `Packages.gz`, `Packages.bz2`, `Release`, and signatures as actual files, with no login, HTML rewrite, or SPA fallback. The host must return 200 with original bytes. Avoid transparent double compression and stale index caches.
8. Add the actual repo URL in Cydia/Zebra, refresh, inspect Mac-Launcher's version/dependencies, then install on the test iPod. Inspect its normal icon layout before and after.

If your host uses GitHub Pages/Jekyll, a `.nojekyll` file at the published root can prevent unwanted processing. Hosting-account setup, custom domains, SSL support in the old device's APT, and repo credentials are outside this source delivery. A real repo URL is needed only when assembling the publication destination and reviewing its existing format.
