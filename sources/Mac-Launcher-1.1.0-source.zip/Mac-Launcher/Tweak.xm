#import <UIKit/UIKit.h>
#import <libactivator/libactivator.h>
#import "Launcher.h"
#import "Shared.h"

@interface OLActivatorListener : NSObject <LAListener>
@end
@implementation OLActivatorListener
- (void)activator:(LAActivator *)activator receiveEvent:(LAEvent *)event forListenerName:(NSString *)name {
    (void)activator; (void)name;
    // Activator dispatches normally on the main thread; marshal synchronously if needed
    // so handled accurately reflects whether we accepted the event.
    __block BOOL accepted = NO;
    if ([NSThread isMainThread]) accepted = OLToggle();
    else dispatch_sync(dispatch_get_main_queue(), ^{ accepted = OLToggle(); });
    if (accepted) event.handled = YES;
}
- (void)activator:(LAActivator *)activator abortEvent:(LAEvent *)event forListenerName:(NSString *)name {
    (void)activator; (void)event; (void)name;
    dispatch_async(dispatch_get_main_queue(), ^{ OLDismiss(); });
}
- (void)activator:(LAActivator *)activator receiveDeactivateEvent:(LAEvent *)event {
    (void)activator; (void)event;
    // Leave event unhandled so a normal Home press retains its standard behavior.
    dispatch_async(dispatch_get_main_queue(), ^{ OLDismiss(); });
}
- (NSString *)activator:(LAActivator *)activator requiresLocalizedTitleForListenerName:(NSString *)name {
    (void)activator; (void)name; return @"Mac-Launcher";
}
- (NSString *)activator:(LAActivator *)activator requiresLocalizedDescriptionForListenerName:(NSString *)name {
    (void)activator; (void)name; return @"Toggle the app drawer or Mac-style dock while unlocked.";
}
- (NSString *)activator:(LAActivator *)activator requiresLocalizedGroupForListenerName:(NSString *)name {
    (void)activator; (void)name; return @"Launchers";
}
- (NSArray *)activator:(LAActivator *)activator requiresCompatibleEventModesForListenerWithName:(NSString *)name {
    (void)activator; (void)name;
    return @[LAEventModeSpringBoard, LAEventModeApplication];
}
- (BOOL)activator:(LAActivator *)activator requiresNeedsPoweredDisplayForListenerName:(NSString *)name {
    (void)activator; (void)name; return YES;
}
@end

%group OLForeground
%hook SpringBoard
- (void)frontDisplayDidChange:(id)display {
    %orig;
    if ([display respondsToSelector:@selector(bundleIdentifier)]) {
        NSString *identifier=[[display bundleIdentifier] copy];
        dispatch_async(dispatch_get_main_queue(), ^{ if (OLCanPresent()) OLRecordRecent(identifier); });
    }
}
%end
%end

%ctor {
    @autoreleasepool {
        static OLActivatorListener *listener;
        listener = [OLActivatorListener new];
        [[LAActivator sharedInstance] registerListener:listener forName:OLDomain];
        if ([NSClassFromString(@"SpringBoard") instancesRespondToSelector:@selector(frontDisplayDidChange:)]) {
            %init(OLForeground);
        }
    }
}
