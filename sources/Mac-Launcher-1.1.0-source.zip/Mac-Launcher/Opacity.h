#pragma once
#include <math.h>
static inline double OLSteppedOpacity(double percent) {
    if (!isfinite(percent)) return 35;
    return round(fmax(0,fmin(100,percent))/5.0)*5.0;
}
