#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import "../Shared.h"

@interface OLAppPicker : PSListController <UISearchBarDelegate>
@property(nonatomic,strong) NSArray<NSDictionary *> *apps;
@property(nonatomic,copy) NSString *query;
@property(nonatomic,strong) UISearchBar *search;
@end
@implementation OLAppPicker
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Launcher Apps";
    self.search = [UISearchBar new];
    self.search.placeholder = @"Search names or bundle IDs";
    self.search.delegate = self;
    [self.search sizeToFit];
    // The iOS 12 runtime exposes -table (despite stale version comments in Theos headers).
    self.table.tableHeaderView = self.search;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh target:self action:@selector(refresh)];
}
- (NSMutableArray *)specifiers {
    if (_specifiers) return _specifiers;
    if (!self.apps) self.apps = OLApplications();
    NSMutableArray *items = [NSMutableArray array];
    PSSpecifier *group = [PSSpecifier emptyGroupSpecifier];
    [group setProperty:@"On = visible inside Mac-Launcher only. Background services are excluded. Refresh after installing or removing apps." forKey:@"footerText"];
    [items addObject:group];
    PSSpecifier *all = [PSSpecifier preferenceSpecifierNamed:@"Show All Apps" target:self set:NULL get:NULL detail:Nil cell:PSButtonCell edit:Nil];
    all.buttonAction = @selector(showAll); [items addObject:all];
    PSSpecifier *none = [PSSpecifier preferenceSpecifierNamed:@"Hide All Apps" target:self set:NULL get:NULL detail:Nil cell:PSButtonCell edit:Nil];
    none.buttonAction = @selector(hideAll); [items addObject:none];
    NSArray *filtered = OLFilter(self.apps,self.query);
    group = [PSSpecifier groupSpecifierWithName:[NSString stringWithFormat:@"%lu apps",(unsigned long)filtered.count]];
    [items addObject:group];
    for (NSDictionary *app in filtered) {
        PSSpecifier *item = [PSSpecifier preferenceSpecifierNamed:app[@"name"] target:self set:@selector(setShown:specifier:) get:@selector(isShown:) detail:Nil cell:PSSwitchCell edit:Nil];
        [item setProperty:app[@"id"] forKey:@"bundleID"];
        [items addObject:item];
    }
    _specifiers = items; return _specifiers;
}
- (id)isShown:(PSSpecifier *)specifier {
    return @(![OLSettings()[@"hiddenIDs"] containsObject:[specifier propertyForKey:@"bundleID"]]);
}
- (void)setShown:(id)value specifier:(PSSpecifier *)specifier {
    NSMutableSet *hidden = [NSMutableSet setWithArray:OLSettings()[@"hiddenIDs"]];
    NSString *identifier = [specifier propertyForKey:@"bundleID"];
    if ([value boolValue]) [hidden removeObject:identifier]; else [hidden addObject:identifier];
    [self saveHidden:hidden.allObjects];
}
- (void)saveHidden:(NSArray *)hidden {
    if (!OLWriteSetting(@"hiddenIDs",[hidden sortedArrayUsingSelector:@selector(compare:)])) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Could not save app selection" message:@"Try reopening Settings." preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
    }
}
- (void)showAll { [self saveHidden:@[]]; [self reloadSpecifiers]; }
- (void)hideAll {
    NSMutableSet *hidden = [NSMutableSet setWithArray:OLSettings()[@"hiddenIDs"]];
    for (NSDictionary *app in self.apps) [hidden addObject:app[@"id"]];
    [self saveHidden:hidden.allObjects]; [self reloadSpecifiers];
}
- (void)refresh { self.apps = OLApplications(); [self reloadSpecifiers]; }
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)text {
    (void)searchBar; self.query = text; [self reloadSpecifiers];
}
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar { [searchBar resignFirstResponder]; }
@end
