#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import "../Shared.h"

// Present in iOS 12 Preferences; omitted from the minimal Theos header.
@interface PSSpecifier (OLListValues)
- (void)setValues:(NSArray *)values titles:(NSArray *)titles;
@end

@interface OLRootController : PSListController
@end
@implementation OLRootController
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self reloadSpecifiers]; // The color wheel can select Custom Color on this page's behalf.
}
- (NSMutableArray *)specifiers {
    if (_specifiers) return _specifiers;
    NSMutableArray *items = [NSMutableArray array];
    PSSpecifier *group = [PSSpecifier emptyGroupSpecifier];
    [group setProperty:@"Assign Home Button → Triple Press to Mac-Launcher in Activator, separately for At Home Screen and In Application. Leave Accessibility Shortcut unassigned. No assignments are changed automatically." forKey:@"footerText"];
    [items addObject:group];
    PSSpecifier *enabled = [PSSpecifier preferenceSpecifierNamed:@"Enabled" target:self set:@selector(setValue:specifier:) get:@selector(valueForSpecifier:) detail:Nil cell:PSSwitchCell edit:Nil];
    [enabled setProperty:@"enabled" forKey:@"key"]; [items addObject:enabled];
    PSSpecifier *style = [PSSpecifier preferenceSpecifierNamed:@"Presentation" target:self set:@selector(setValue:specifier:) get:@selector(valueForSpecifier:) detail:NSClassFromString(@"PSListItemsController") cell:PSLinkListCell edit:Nil];
    [style setProperty:@"style" forKey:@"key"];
    [style setValues:@[@0,@1] titles:@[@"App Drawer",@"Mac-style Dock"]]; [items addObject:style];
    group = [PSSpecifier groupSpecifierWithName:@"Appearance"];
    [group setProperty:@"Choose Dark, Light, or Custom Color. Surface Opacity: 0 = clear, 100 = solid, in 5% steps. App icons and text stay opaque. Reduce Transparency disables blur while the opacity slider still controls surface fill. Reopen Mac-Launcher to see changes." forKey:@"footerText"];
    [items addObject:group];
    PSSpecifier *theme = [PSSpecifier preferenceSpecifierNamed:@"Theme" target:self set:@selector(setValue:specifier:) get:@selector(valueForSpecifier:) detail:NSClassFromString(@"PSListItemsController") cell:PSLinkListCell edit:Nil];
    [theme setProperty:@"theme" forKey:@"key"];
    [theme setValues:@[@0,@1,@2] titles:@[@"Dark",@"Light",@"Custom Color"]];[items addObject:theme];
    [items addObject:[PSSpecifier preferenceSpecifierNamed:@"Custom Color Wheel" target:self set:NULL get:NULL detail:NSClassFromString(@"OLColorController") cell:PSLinkCell edit:Nil]];
    PSSpecifier *opacity = [PSSpecifier preferenceSpecifierNamed:@"Surface Opacity" target:self set:NULL get:NULL detail:Nil cell:PSStaticTextCell edit:Nil];
    [opacity setProperty:NSClassFromString(@"OLOpacityCell") forKey:@"cellClass"];
    [opacity setProperty:@80 forKey:@"height"];
    [opacity setProperty:@"surfaceOpacity" forKey:@"key"];
    [opacity setProperty:@YES forKey:@"enabled"];
    [items addObject:opacity];
    PSSpecifier *dockBlur = [PSSpecifier preferenceSpecifierNamed:@"Blur Behind Dock" target:self set:@selector(setValue:specifier:) get:@selector(valueForSpecifier:) detail:Nil cell:PSSwitchCell edit:Nil];
    [dockBlur setProperty:@"dockBlur" forKey:@"key"]; [items addObject:dockBlur];
    PSSpecifier *list = [PSSpecifier preferenceSpecifierNamed:@"Use List in Drawer" target:self set:@selector(setValue:specifier:) get:@selector(valueForSpecifier:) detail:Nil cell:PSSwitchCell edit:Nil];
    [list setProperty:@"list" forKey:@"key"]; [items addObject:list];
    PSSpecifier *dim = [PSSpecifier preferenceSpecifierNamed:@"Background Dimming" target:self set:@selector(setValue:specifier:) get:@selector(valueForSpecifier:) detail:NSClassFromString(@"PSListItemsController") cell:PSLinkListCell edit:Nil];
    [dim setProperty:@"dim" forKey:@"key"];
    [dim setValues:@[@0.0,@0.28,@0.55] titles:@[@"Blur Only",@"Medium",@"Dark"]]; [items addObject:dim];
    group = [PSSpecifier emptyGroupSpecifier];
    [group setProperty:@"App switches affect only Mac-Launcher. All apps are initially shown. New apps are shown until you turn them off. SpringBoard icons and their positions stay unchanged." forKey:@"footerText"];
    [items addObject:group];
    [items addObject:[PSSpecifier preferenceSpecifierNamed:@"Apps" target:self set:NULL get:NULL detail:NSClassFromString(@"OLAppPicker") cell:PSLinkCell edit:Nil]];
    PSSpecifier *help = [PSSpecifier preferenceSpecifierNamed:@"Gesture Setup & Conflicts" target:self set:NULL get:NULL detail:Nil cell:PSButtonCell edit:Nil];
    help.buttonAction = @selector(showHelp); [items addObject:help];
    _specifiers = items; return _specifiers;
}
- (id)valueForSpecifier:(PSSpecifier *)specifier { return OLSettings()[[specifier propertyForKey:@"key"]]; }
- (void)setValue:(id)value specifier:(PSSpecifier *)specifier {
    if ([[specifier propertyForKey:@"key"] isEqualToString:@"surfaceOpacity"])
        value = @(MAX(0,MIN(100,[value doubleValue])));
    if (!OLWriteSetting([specifier propertyForKey:@"key"],value)) [self showWriteError];
}
- (void)showWriteError {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Could not save" message:@"Preferences could not be synchronized. Try reopening Settings." preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}
- (void)showHelp {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Home Triple Press" message:@"1. Install a working iOS 12 Activator build.\n2. In Settings → General → Accessibility → Accessibility Shortcut, uncheck all shortcuts only if you do not rely on them.\n3. In Activator, assign Home Button → Triple Press to Mac-Launcher at Home Screen and In Application. Remove conflicting assignments yourself. Do not assign it on the lock screen.\n\nIf you need the Accessibility shortcut, keep it and assign Mac-Launcher to a different Activator gesture. Mac-Launcher never changes these settings for you.\n\nTap Close, the backdrop, or Home to dismiss. Scroll the dock to browse and magnify apps. Tap the magnifying glass for search." preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}
@end
