#import <Preferences/PSViewController.h>
#import "../Shared.h"
#import <math.h>
#import <stdlib.h>

// UIKit has no system color picker on iOS 12. Draw our own HSB wheel.
@interface OLColorWheel : UIControl
@property(nonatomic) CGFloat hue;
@property(nonatomic) CGFloat saturation;
@property(nonatomic,strong) UIImage *wheelImage;
@end
@implementation OLColorWheel
- (instancetype)initWithFrame:(CGRect)frame {
    if ((self=[super initWithFrame:frame])) {
        self.backgroundColor=UIColor.clearColor;
        self.isAccessibilityElement=NO; // The three labeled sliders provide the accessible equivalent.
        const size_t size=512;
        unsigned char *pixels=calloc(size*size,4);
        if (pixels) {
            for (size_t y=0;y<size;y++) for (size_t x=0;x<size;x++) {
                double dx=(x+0.5)/size*2-1,dy=(y+0.5)/size*2-1;
                double s=hypot(dx,dy);
                if (s>1) continue;
                double h=atan2(dy,dx)/(2*M_PI); if (h<0) h+=1;
                double v=h*6,f=v-floor(v),q=1-s*f,t=1-s*(1-f),p=1-s;
                double r=1,g=1,b=1;
                switch ((int)floor(v)%6) {
                    case 0:r=1;g=t;b=p;break; case 1:r=q;g=1;b=p;break;
                    case 2:r=p;g=1;b=t;break; case 3:r=p;g=q;b=1;break;
                    case 4:r=t;g=p;b=1;break; default:r=1;g=p;b=q;break;
                }
                size_t i=(y*size+x)*4;
                pixels[i]=(unsigned char)lround(r*255); pixels[i+1]=(unsigned char)lround(g*255);
                pixels[i+2]=(unsigned char)lround(b*255); pixels[i+3]=255;
            }
            CGColorSpaceRef space=CGColorSpaceCreateDeviceRGB();
            CGContextRef context=CGBitmapContextCreate(pixels,size,size,8,size*4,space,kCGImageAlphaPremultipliedLast|kCGBitmapByteOrder32Big);
            if (context) {
                CGImageRef image=CGBitmapContextCreateImage(context);
                if (image) {self.wheelImage=[UIImage imageWithCGImage:image];CGImageRelease(image);}
                CGContextRelease(context);
            }
            CGColorSpaceRelease(space); free(pixels);
        }
    } return self;
}
- (CGRect)wheelRect { return CGRectInset(self.bounds,10,10); }
- (void)drawRect:(CGRect)rect {
    (void)rect;
    CGRect wheel=[self wheelRect]; [self.wheelImage drawInRect:wheel];
    CGFloat angle=self.hue*2*M_PI,radius=self.saturation*wheel.size.width/2;
    CGPoint point=CGPointMake(CGRectGetMidX(wheel)+cos(angle)*radius,CGRectGetMidY(wheel)+sin(angle)*radius);
    UIBezierPath *ring=[UIBezierPath bezierPathWithOvalInRect:CGRectMake(point.x-8,point.y-8,16,16)];
    [UIColor.blackColor setStroke]; ring.lineWidth=4;[ring stroke];
    [UIColor.whiteColor setStroke]; ring.lineWidth=2;[ring stroke];
}
- (BOOL)updateTouch:(UITouch *)touch {
    CGRect wheel=[self wheelRect]; CGPoint point=[touch locationInView:self];
    CGFloat dx=point.x-CGRectGetMidX(wheel),dy=point.y-CGRectGetMidY(wheel);
    self.hue=atan2(dy,dx)/(2*M_PI); if (self.hue<0) self.hue+=1;
    self.saturation=MIN(1,hypot(dx,dy)/MAX(1,wheel.size.width/2));
    [self setNeedsDisplay]; [self sendActionsForControlEvents:UIControlEventValueChanged]; return YES;
}
- (BOOL)beginTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event { (void)event;return [self updateTouch:touch]; }
- (BOOL)continueTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event { (void)event;return [self updateTouch:touch]; }
@end

@interface OLColorController : PSViewController
@property(nonatomic,strong) UIScrollView *scroll;
@property(nonatomic,strong) OLColorWheel *wheel;
@property(nonatomic,strong) UILabel *preview;
@property(nonatomic,strong) UILabel *help;
@property(nonatomic,strong) NSArray<UILabel *> *labels;
@property(nonatomic,strong) NSArray<UISlider *> *sliders;
@property(nonatomic) NSUInteger saveGeneration;
@property(nonatomic) BOOL pendingColor;
@end
@implementation OLColorController
- (void)loadView {
    self.title=@"Custom Color";
    self.scroll=[UIScrollView new]; self.scroll.backgroundColor=[UIColor colorWithWhite:0.96 alpha:1]; self.view=self.scroll;
    NSDictionary *settings=OLSettings();
    self.wheel=[OLColorWheel new]; self.wheel.hue=[settings[@"customHue"] doubleValue]; self.wheel.saturation=[settings[@"customSaturation"] doubleValue];
    [self.wheel addTarget:self action:@selector(wheelChanged) forControlEvents:UIControlEventValueChanged];
    [self.scroll addSubview:self.wheel];
    self.preview=[UILabel new];self.preview.textAlignment=NSTextAlignmentCenter;
    self.preview.layer.cornerRadius=16;self.preview.clipsToBounds=YES;[self.scroll addSubview:self.preview];
    NSMutableArray *labels=[NSMutableArray array],*sliders=[NSMutableArray array];
    NSArray *names=@[@"Hue",@"Saturation",@"Brightness"];
    NSArray *keys=@[@"customHue",@"customSaturation",@"customBrightness"];
    for (NSUInteger i=0;i<names.count;i++) {
        UILabel *label=[UILabel new]; label.font=[UIFont systemFontOfSize:15];[labels addObject:label];[self.scroll addSubview:label];
        UISlider *slider=[UISlider new];slider.minimumValue=0;slider.maximumValue=1;
        slider.value=[settings[keys[i]] floatValue];slider.accessibilityLabel=names[i];
        [slider addTarget:self action:@selector(slidersChanged) forControlEvents:UIControlEventValueChanged];
        [sliders addObject:slider];[self.scroll addSubview:slider];
    }
    self.labels=labels;self.sliders=sliders;
    self.help=[UILabel new];self.help.numberOfLines=0;self.help.font=[UIFont systemFontOfSize:14];self.help.textColor=UIColor.darkGrayColor;
    self.help.text=@"Drag around the wheel to choose a hue; move toward the center for softer colors. Brightness changes how light or dark it is. Choosing a color selects Custom Color as your theme. Surface Opacity stays separate.";
    [self.scroll addSubview:self.help];[self updatePreview];
}
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    CGFloat w=self.view.bounds.size.width,side=MIN(260,w-32);
    self.wheel.frame=CGRectMake((w-side)/2,12,side,side);
    CGFloat y=CGRectGetMaxY(self.wheel.frame)+12;
    self.preview.frame=CGRectMake(20,y,w-40,48);y+=64;
    for (NSUInteger i=0;i<3;i++) {
        self.labels[i].frame=CGRectMake(20,y,w-40,22);
        self.sliders[i].frame=CGRectMake(20,y+22,w-40,36);y+=66;
    }
    CGSize help=[self.help sizeThatFits:CGSizeMake(w-40,CGFLOAT_MAX)];
    self.help.frame=CGRectMake(20,y,w-40,help.height);self.scroll.contentSize=CGSizeMake(w,y+help.height+24);
}
- (void)wheelChanged {
    self.sliders[0].value=self.wheel.hue;self.sliders[1].value=self.wheel.saturation;[self saveColor];
}
- (void)slidersChanged {
    self.wheel.hue=self.sliders[0].value;self.wheel.saturation=self.sliders[1].value;
    [self.wheel setNeedsDisplay];[self saveColor];
}
- (void)updatePreview {
    UIColor *color=[UIColor colorWithHue:self.sliders[0].value saturation:self.sliders[1].value brightness:self.sliders[2].value alpha:1];
    self.preview.backgroundColor=color;self.preview.textColor=OLUsesLightText(color) ? UIColor.whiteColor : UIColor.blackColor;
    CGFloat r=0,g=0,b=0,a=1;[color getRed:&r green:&g blue:&b alpha:&a];
    self.preview.text=[NSString stringWithFormat:@"#%02X%02X%02X",(int)lround(r*255),(int)lround(g*255),(int)lround(b*255)];
    NSArray *names=@[@"Hue",@"Saturation",@"Brightness"];
    for (NSUInteger i=0;i<3;i++) {
        NSString *value=[NSString stringWithFormat:@"%.0f%@",self.sliders[i].value*(i ? 100 : 360),i ? @"%" : @"°"];
        self.labels[i].text=[NSString stringWithFormat:@"%@: %@",names[i],value];self.sliders[i].accessibilityValue=value;
    }
}
- (void)saveColor {
    [self updatePreview];
    self.pendingColor=YES;
    NSUInteger generation=++self.saveGeneration;
    __weak OLColorController *weakSelf=self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(0.12*NSEC_PER_SEC)),dispatch_get_main_queue(),^{
        OLColorController *controller=weakSelf;
        if (controller && controller.saveGeneration==generation) [controller commitColor];
    });
}
- (void)commitColor {
    if (!self.pendingColor) return;
    if (!OLWriteSettings(@{@"theme":@2,@"customHue":@(self.sliders[0].value),@"customSaturation":@(self.sliders[1].value),@"customBrightness":@(self.sliders[2].value)}))
        self.preview.text=@"Color not saved — try again";
    else self.pendingColor=NO;
}
- (void)viewWillDisappear:(BOOL)animated {
    ++self.saveGeneration;[self commitColor];
    [super viewWillDisappear:animated];
}
@end
