#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
: "${THEOS:?Install Theos and export THEOS first; see README.md}"
test -f "$THEOS/makefiles/common.mk" || { echo 'Theos installation is incomplete.' >&2; exit 1; }
test -f "$THEOS/vendor/include/libactivator/libactivator.h" || test -f "$THEOS/include/libactivator/libactivator.h" || {
    echo 'Missing Activator headers. Update Theos recursive submodules.' >&2; exit 1;
}
# Windows-mounted source copies can carry mode 0777; normalize package inputs.
find layout prefs/Resources -type d -exec chmod 755 {} +
find layout prefs/Resources -type f -exec chmod 644 {} +
chmod 755 layout/DEBIAN/postinst layout/DEBIAN/postrm
make clean THEOS_PACKAGE_SCHEME=
make package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME= "$@"
echo 'Built packages are in packages/. Validate and test privately before publishing.'
