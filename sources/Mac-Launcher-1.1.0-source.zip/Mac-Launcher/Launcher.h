#import <UIKit/UIKit.h>
#ifdef __cplusplus
extern "C" {
#endif
BOOL OLCanPresent(void);
BOOL OLToggle(void);
void OLDismiss(void);
#ifdef __cplusplus
}
#endif
