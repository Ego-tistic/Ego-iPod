# Empty development scaffold

Packages contains zero records. Release and the compressed indexes describe that empty index accurately. There is no installable tweak here until a real `.deb` has been built, tested, placed under `debs/`, and indexed again. See ../REPO.md. Do not replace an existing repository with this scaffold.
