#import "Shared.h"
#import <math.h>
#import "Opacity.h"

NSString * const OLDomain = @"io.github.orbitlauncher";
CFStringRef const OLChanged = CFSTR("io.github.orbitlauncher.changed");

NSDictionary *OLSettings(void) {
    CFPreferencesSynchronize((__bridge CFStringRef)OLDomain, kCFPreferencesCurrentUser, kCFPreferencesAnyHost);
    NSDictionary *saved = CFBridgingRelease(CFPreferencesCopyMultiple(NULL,
        (__bridge CFStringRef)OLDomain, kCFPreferencesCurrentUser, kCFPreferencesAnyHost));
    NSMutableDictionary *settings = [@{@"enabled": @YES, @"style": @0,
        @"list": @NO, @"hiddenIDs": @[], @"dim": @0.28, @"dockBlur": @NO,
        @"darkTheme": @YES, @"surfaceOpacity": @35,
        @"customHue": @0.58, @"customSaturation": @0.65, @"customBrightness": @0.28} mutableCopy];
    if ([saved isKindOfClass:[NSDictionary class]]) [settings addEntriesFromDictionary:saved];
    if (![settings[@"hiddenIDs"] isKindOfClass:[NSArray class]]) settings[@"hiddenIDs"] = @[];
    settings[@"surfaceOpacity"]=@(OLSteppedOpacity([settings[@"surfaceOpacity"] doubleValue]));
    // Migrate the old theme switch without changing existing preferences or IDs.
    NSInteger theme=settings[@"theme"] ? [settings[@"theme"] integerValue] : ([settings[@"darkTheme"] boolValue] ? 0 : 1);
    settings[@"theme"]=@(MAX(0,MIN(2,theme)));
    for (NSString *key in @[@"customHue",@"customSaturation",@"customBrightness"]) {
        double value=[settings[key] doubleValue];
        settings[key]=@(isfinite(value) ? fmax(0,fmin(1,value)) : 0);
    }
    return settings;
}

BOOL OLWriteSetting(NSString *key, id value) {
    return OLWriteSettings(@{key:value});
}

BOOL OLWriteSettings(NSDictionary *values) {
    NSMutableDictionary *normalized=[values mutableCopy];
    if (normalized[@"surfaceOpacity"]) normalized[@"surfaceOpacity"]=@(OLSteppedOpacity([normalized[@"surfaceOpacity"] doubleValue]));
    CFPreferencesSetMultiple((__bridge CFDictionaryRef)normalized,NULL,(__bridge CFStringRef)OLDomain,
                             kCFPreferencesCurrentUser,kCFPreferencesAnyHost);
    BOOL ok = CFPreferencesSynchronize((__bridge CFStringRef)OLDomain,kCFPreferencesCurrentUser,kCFPreferencesAnyHost);
    if (ok) CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                                                OLChanged, NULL, NULL, true);
    return ok;
}

UIColor *OLSurfaceColor(NSDictionary *settings) {
    switch ([settings[@"theme"] integerValue]) {
        case 1: return [UIColor colorWithWhite:0.98 alpha:1];
        case 2: return [UIColor colorWithHue:[settings[@"customHue"] doubleValue]
                                saturation:[settings[@"customSaturation"] doubleValue]
                                brightness:[settings[@"customBrightness"] doubleValue] alpha:1];
        default: return [UIColor colorWithWhite:0.08 alpha:1];
    }
}
BOOL OLUsesLightText(UIColor *color) {
    CGFloat r=0,g=0,b=0,a=1;
    [color getRed:&r green:&g blue:&b alpha:&a];
    return (0.2126*r+0.7152*g+0.0722*b)<0.55;
}

NSArray<NSDictionary *> *OLApplications(void) {
    Class cls = NSClassFromString(@"LSApplicationWorkspace");
    if (![cls respondsToSelector:@selector(defaultWorkspace)]) return @[];
    LSApplicationWorkspace *workspace = [cls defaultWorkspace];
    if (![workspace respondsToSelector:@selector(allApplications)]) return @[];
    NSMutableDictionary *unique = [NSMutableDictionary dictionary];
    @try {
        for (LSApplicationProxy *proxy in [workspace allApplications]) {
            if (![proxy respondsToSelector:@selector(applicationIdentifier)] ||
                ![proxy respondsToSelector:@selector(localizedName)]) continue;
            NSString *identifier = [proxy applicationIdentifier];
            NSString *name = [proxy localizedName];
            if (!identifier.length || !name.length || [identifier isEqualToString:@"com.apple.springboard"]) continue;
            // Omit background system services tagged hidden by LaunchServices.
            if ([proxy respondsToSelector:@selector(appTags)] && [[proxy appTags] containsObject:@"hidden"]) continue;
            if ([proxy respondsToSelector:@selector(applicationType)]) {
                NSString *type = [proxy applicationType];
                if (type && ![type isEqualToString:@"User"] && ![type isEqualToString:@"System"]) continue;
            }
            unique[identifier] = @{@"id": identifier, @"name": name};
        }
    } @catch (NSException *exception) {
        NSLog(@"[Mac-Launcher] Catalog unavailable: %@", exception.name);
    }
    return [[unique allValues] sortedArrayUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
        NSComparisonResult result = [a[@"name"] localizedCaseInsensitiveCompare:b[@"name"]];
        return result == NSOrderedSame ? [a[@"id"] compare:b[@"id"]] : result;
    }];
}

NSArray<NSDictionary *> *OLFilter(NSArray<NSDictionary *> *apps, NSString *query) {
    if (!query.length) return apps;
    return [apps filteredArrayUsingPredicate:[NSPredicate predicateWithBlock:^BOOL(NSDictionary *app, NSDictionary *bindings) {
        (void)bindings;
        NSStringCompareOptions options = NSCaseInsensitiveSearch | NSDiacriticInsensitiveSearch;
        return [app[@"name"] rangeOfString:query options:options].location != NSNotFound ||
               [app[@"id"] rangeOfString:query options:options].location != NSNotFound;
    }]];
}

UIImage *OLIcon(NSString *identifier) {
    static NSCache *cache;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ cache=[NSCache new]; cache.countLimit=128; });
    UIImage *cached=[cache objectForKey:identifier];
    if (cached) return cached;
    @try {
        if ([UIImage respondsToSelector:@selector(_applicationIconImageForBundleIdentifier:format:scale:)]) {
            // Reserve actual pixels for the 72pt magnified icon, without resizing
            // a small settings/search bitmap up into a larger image.
            CGFloat scale=MAX(3.0,[UIScreen mainScreen].scale);
            UIImage *image=[UIImage _applicationIconImageForBundleIdentifier:identifier format:2 scale:scale];
            size_t pixels=image.CGImage ? CGImageGetWidth(image.CGImage) : 0;
            if (pixels < (size_t)ceil(72*[UIScreen mainScreen].scale)) {
                UIImage *fallback=[UIImage _applicationIconImageForBundleIdentifier:identifier format:0 scale:scale];
                if (fallback.CGImage && CGImageGetWidth(fallback.CGImage)>pixels) image=fallback;
            }
            if (image) [cache setObject:image forKey:identifier];
            return image;
        }
    } @catch (__unused NSException *exception) {}
    return nil; // Text labels remain usable when icon lookup fails.
}

BOOL OLOpen(NSString *identifier) {
    Class cls = NSClassFromString(@"LSApplicationWorkspace");
    if (![cls respondsToSelector:@selector(defaultWorkspace)]) return NO;
    id workspace = [cls defaultWorkspace];
    if (![workspace respondsToSelector:@selector(openApplicationWithBundleID:)]) return NO;
    @try { return [workspace openApplicationWithBundleID:identifier]; }
    @catch (__unused NSException *exception) { return NO; }
}

void OLRecordRecent(NSString *identifier) {
    if (![identifier isKindOfClass:NSString.class] || !identifier.length || [identifier isEqualToString:@"com.apple.springboard"]) return;
    id saved=OLSettings()[@"recentIDs"];
    NSMutableArray *recent=[saved isKindOfClass:NSArray.class] ? [saved mutableCopy] : [NSMutableArray array];
    if ([recent.firstObject isEqual:identifier]) return;
    [recent removeObject:identifier]; [recent insertObject:identifier atIndex:0];
    while (recent.count>5) [recent removeLastObject];
    // Separate history key; do not post the appearance-change notification.
    CFPreferencesSetAppValue(CFSTR("recentIDs"),(__bridge CFArrayRef)recent,(__bridge CFStringRef)OLDomain);
    CFPreferencesAppSynchronize((__bridge CFStringRef)OLDomain);
}
void OLCaptureFrontApp(void) {
    UIApplication *app=UIApplication.sharedApplication;
    if (![app respondsToSelector:@selector(_accessibilityFrontMostApplication)]) return;
    @try {
        id front=[app _accessibilityFrontMostApplication];
        if ([front respondsToSelector:@selector(bundleIdentifier)]) OLRecordRecent([front bundleIdentifier]);
    } @catch (__unused NSException *exception) {}
}
