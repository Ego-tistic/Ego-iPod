> Superseded analysis: see [BLUETOOTHD-REVIEW.md](BLUETOOTHD-REVIEW.md). The old second getter is a supported-features version, not a product ID. Beta2 has no mapping hooks.

# Research and design decisions — November 4, 2026

## Disconnects are not a diagnosis

The user reports that both AirPods Pro 3 and AirPods Max connect, then disconnect seconds later. No crash log, current daemon PID trace, headphone firmware version or Max connector/model detail was supplied. This session did not connect to the iPod. A daemon restart, accessory-side disconnect, firmware mismatch and audio-profile issue remain distinct possibilities. This release does not claim to resolve the underlying cause or to detect headphone connection state.

## Why test a different identity

[Apple's setup compatibility list](https://support.apple.com/en-us/104989) lists AirPods 2 at iOS 12.2+, original Pro at iOS 13.2+ and Pro 3 at iOS 26+. The published Pro-Pods diagnostic2 maps Pro 3 IDs to original Pro. The new Legacy Audio default instead uses AirPods 2 identity to exercise an older model path. That supported identity is a rationale for the experiment, not evidence that spoofing it makes different hardware stable.

[Apple's generic Bluetooth guide](https://support.apple.com/en-us/108786) distinguishes generic headset use from newer Apple integration. Modern features must not be advertised as backported by an ID-only tweak.

## Product IDs

Pro 3 values 8231/8232 follow the existing verified profile and [PodsGrant's preset table](https://github.com/LNSSPsd/PodsGrant/blob/d727bf4f26474b6504be82fdbe0f391ff746db6d/general.h). Lightning Max 8202, USB-C Max 8223 and Max 2 8237 are cross-referenced in [airpods-fw's source](https://github.com/mooons/airpods-fw/blob/main/airpods-fw). Its documentation cites Bluetooth observations/AirBattery and the Max 2 CoreBluetoothUI asset mapping. This session inspected that source, not the headphones or those macOS assets. Max 2 is opt-in; unknown products remain unchanged. No code from that separate project is copied.

## Upstream and inherited evidence

Reviewed [PodsGrant](https://github.com/LNSSPsd/PodsGrant/tree/d727bf4f26474b6504be82fdbe0f391ff746db6d). Its upstream build targets iOS 13 and later, scans for function signatures, modifies device object fields, and includes volume/capability/Sharing integrations. It cannot simply be dropped onto iOS 12. The user-owned private Pro-Pods source has an iPod7,1/iOS 12.5.8 UUID and complete getter hashes established in an earlier binary investigation. Those checks are retained exactly. Their presence proves what bytes are required, not that the new hook behavior has been tested on-device.

The new implementation intercepts getter outputs only. It adds bounded, scalar-only diagnostics and an explicit fresh-response status handshake, rather than globally suppressing logs or blindly patching BLE data. A verified function address does not prove model-protocol compatibility; more invasive changes require a relevant fresh crash report or binary trace.
