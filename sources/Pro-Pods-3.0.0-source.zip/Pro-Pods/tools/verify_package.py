#!/usr/bin/env python3
import argparse, hashlib, io, plistlib, struct, subprocess, tarfile
from pathlib import Path
def verify_macho(data, name, expected_type=6):
    magic, cpu, subtype, filetype, count, commands_size, flags, reserved = struct.unpack_from('<8I', data)
    assert magic == 0xFEEDFACF and cpu == 0x0100000C, f'{name}: expected thin arm64 Mach-O'
    assert filetype == expected_type, f'{name}: expected dynamically linked library'
    position = 32
    minimum = sdk = signature = None
    libraries = []
    for _ in range(count):
        command, size = struct.unpack_from('<II', data, position)
        assert size >= 8 and position + size <= 32 + commands_size
        if command == 0x25:  # LC_VERSION_MIN_IPHONEOS
            minimum, sdk = struct.unpack_from('<II', data, position + 8)
        elif command == 0x32:  # LC_BUILD_VERSION
            platform, minimum, sdk = struct.unpack_from('<III', data, position + 8)
            assert platform == 2, f'{name}: expected iOS device platform'
        elif command == 0x1D:  # LC_CODE_SIGNATURE
            signature = struct.unpack_from('<II', data, position + 8)
        elif command in (0xC, 0x18 | 0x80000000, 0x1F | 0x80000000):
            start, = struct.unpack_from('<I', data, position + 8)
            libraries.append(data[position+start:position+size].split(b'\0', 1)[0].decode())
        position += size
    assert minimum == 12 << 16, f'{name}: minimum OS must be 12.0'
    assert sdk == (12 << 16 | 4 << 8), f'{name}: expected iOS 12.4 SDK build'
    assert signature is not None, f'{name}: missing code signature'
    assert not any('/var/jb' in path for path in libraries), f'{name}: rootless dependency'
    offset, length = signature
    blob = data[offset:offset+length]
    blob_magic, blob_size, blob_count = struct.unpack_from('>III', blob)
    assert blob_magic == 0xFADE0CC0 and blob_size <= len(blob)
    directories = 0
    for entry in range(blob_count):
        slot, relative = struct.unpack_from('>II', blob, 12 + entry * 8)
        if slot != 0 and not 0x1000 <= slot < 0x1006:
            continue
        directory = blob[relative:]
        (cd_magic, cd_length, version, cd_flags, hash_offset, ident_offset,
         special_count, code_count, code_limit) = struct.unpack_from('>9I', directory)
        assert cd_magic == 0xFADE0C02 and cd_length <= len(directory)
        assert cd_flags & 2, f'{name}: expected ad-hoc signature flag'
        hash_size, hash_type, platform, page_power = struct.unpack_from('>4B', directory, 36)
        algorithm = {1: 'sha1', 2: 'sha256', 3: 'sha256', 4: 'sha384'}[hash_type]
        page_size = 1 << page_power
        assert code_limit == offset and code_count == (code_limit + page_size - 1) // page_size
        assert hash_offset + code_count * hash_size <= cd_length
        for page in range(code_count):
            page_data = data[page*page_size:min((page+1)*page_size, code_limit)]
            expected = directory[hash_offset+page*hash_size:hash_offset+(page+1)*hash_size]
            assert hashlib.new(algorithm, page_data).digest()[:hash_size] == expected, f'{name}: code page hash mismatch'
        directories += 1
    assert directories, f'{name}: no signed code directory'
    print(f'PASS: {name}: arm64, minimum iOS 12.0, SDK 12.4, {directories} ad-hoc code directory/directories verified')
    for library in libraries:
        print(f'  dependency: {library}')



def main():
    parser=argparse.ArgumentParser();parser.add_argument('deb',type=Path);a=parser.parse_args()
    info=subprocess.run(['dpkg-deb','--field',str(a.deb)],check=True,capture_output=True,text=True).stdout
    assert 'Package: com.propods.tweak\n' in info and 'Version: 3.0.0\n' in info
    assert 'Architecture: iphoneos-arm\n' in info
    assert all(x in info for x in ['preferenceloader','mobilesubstrate','firmware (>= 12.5.8)','firmware (<< 12.5.9)','Conflicts: com.lns.pogr'])
    blob=subprocess.run(['dpkg-deb','--fsys-tarfile',str(a.deb)],check=True,capture_output=True).stdout
    with tarfile.open(fileobj=io.BytesIO(blob),mode='r:*') as tar:
        members={m.name.removeprefix('./'):m for m in tar.getmembers()}
        for name,m in members.items():
            assert '..' not in Path(name).parts and not name.startswith('/') and 'var/jb' not in name
            assert m.uid==m.gid==0 and not m.mode&0o002
        for name,kind in [('Library/MobileSubstrate/DynamicLibraries/Pro-Pods.dylib',6),('Library/PreferenceBundles/ProPodsPrefs.bundle/ProPodsPrefs',6),('usr/bin/pro-podsctl',2)]:
            verify_macho(tar.extractfile(members[name]).read(),name,kind)
        for name in ['Library/PreferenceBundles/ProPodsPrefs.bundle/Info.plist','Library/PreferenceLoader/Preferences/Pro-Pods.plist']:
            plistlib.loads(tar.extractfile(members[name]).read())
        filter=tar.extractfile(members['Library/MobileSubstrate/DynamicLibraries/Pro-Pods.plist']).read()
        assert b'bluetoothd' in filter and b'sharingd' not in filter
        assert 'var/lib/pro-pods' in members and members['var/lib/pro-pods'].mode==0o755
        assert 'usr/share/doc/com.propods.tweak/copyright' in members
    print('PASS: package identity, firmware/dependency constraints, rootful paths, ownership/modes, XML, bluetoothd-only filter and recovery directory')
    print('SHA256:',hashlib.sha256(a.deb.read_bytes()).hexdigest())
    print('NOT TESTED: actual pairing/audio/disconnects, live preferences, status IPC and recovery on iPod hardware.')
if __name__=='__main__':main()
