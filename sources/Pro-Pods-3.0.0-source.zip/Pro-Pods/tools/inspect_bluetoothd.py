"""Read-only Mach-O inspection; never executes or modifies the input binary."""
import argparse
import bisect
import pathlib
import re
import struct
import uuid

p = argparse.ArgumentParser()
p.add_argument('binary', type=pathlib.Path)
p.add_argument('--offset', type=lambda x: int(x, 0), action='append', default=[])
p.add_argument('--full', action='store_true')
p.add_argument('--prefixes', action='store_true')
p.add_argument('--strings', action='append', default=[])
p.add_argument('--xref', type=lambda x: int(x,0), action='append', default=[])
a = p.parse_args()
b = a.binary.read_bytes()
def u32(o): return struct.unpack_from('<I', b, o)[0]
assert u32(0) == 0xfeedfacf
sections, starts, symbols = [], [], {}
pos = 32
symtab = dysymtab = None
base = None
function_data = None
for _ in range(u32(16)):
    cmd, size = struct.unpack_from('<II', b, pos)
    assert size >= 8 and pos + size <= len(b)
    if cmd == 0x1b:
        print('UUID:', uuid.UUID(bytes=b[pos+8:pos+24]))
    if cmd == 0x19:
        segname = b[pos+8:pos+24].rstrip(b'\0').decode()
        vm, vmsize, off, length = struct.unpack_from('<QQQQ', b, pos+24)
        if segname == '__TEXT': base = vm
        for j in range(u32(pos+64)):
            s = pos+72+j*80
            name = b[s:s+16].rstrip(b'\0').decode()
            addr, n, offset = struct.unpack_from('<QQI', b, s+32)
            sections.append((name, addr, n, offset, u32(s+68), u32(s+72)))
    if cmd == 2: symtab = struct.unpack_from('<IIII', b, pos+8)
    if cmd == 0xb: dysymtab = struct.unpack_from('<18I', b, pos+8)
    if cmd == 0x26: function_data = struct.unpack_from('<II', b, pos+8)
    if cmd == 0x2c: print('Encryption:', u32(pos+16))
    pos += size
if function_data:
    off, n = function_data
    value = shift = 0
    current = base
    for byte in b[off:off+n]:
        value |= (byte & 127) << shift
        if byte & 128: shift += 7; continue
        if value == 0: break
        current += value
        starts.append(current)
        value = shift = 0
if symtab:
    off, count, strings, _ = symtab
    names = []
    for i in range(count):
        strx, typ, sect, desc, value = struct.unpack_from('<IBBHQ', b, off+i*16)
        end = b.find(b'\0', strings+strx)
        name = b[strings+strx:end].decode(errors='replace')
        names.append(name)
        if value: symbols[value] = name
    if dysymtab:
        indirect = dysymtab[12]
        for name, addr, n, offset, r1, r2 in sections:
            if name == '__stubs':
                for i in range(n//r2):
                    index = u32(indirect+(r1+i)*4)
                    if index < len(names): symbols[addr+i*r2] = names[index]
print('CPU/subtype:', hex(u32(4)), hex(u32(8)), 'function starts:', len(starts))
source = (pathlib.Path(__file__).resolve().parents[1]/'address_finder.c').read_text()
words = struct.unpack_from('<'+'I'*(len(b)//4), b)
for name in ('first', 'second'):
    literal = re.search(rf'{name}\[\] = \{{(.*?)\}};', source, re.S)[1]
    nums = [int(x,16) for x in re.findall(r'0x[0-9a-f]+',literal)]
    matches = [i*4 for i in range(len(words)-len(nums)//2+1)
               if all(words[i+j] & nums[j*2] == nums[j*2+1] for j in range(len(nums)//2))]
    print(name, 'matches:', [hex(x) for x in matches])
    if a.prefixes:
        ranked = []
        for entry in starts:
            i = (entry-base)//4
            if i + len(nums)//2 >= len(words): continue
            score = sum(words[i+j] & nums[j*2] == nums[j*2+1] for j in range(len(nums)//2))
            ranked.append((score, entry-base))
        print('Most similar function entries:', [(score, hex(off)) for score,off in sorted(ranked,reverse=True)[:12]])
    if name == 'first' and len(matches) == 1:
        print('Product field offset:', hex(((u32(matches[0]+24)>>10)&4095)*4))
    a.offset += matches
if a.strings:
    for term in a.strings:
        for match in re.finditer(rb'[^\x00\n]{0,160}'+re.escape(term.encode())+rb'[^\x00\n]{0,160}',b,re.I):
            print('STRING',hex(match.start()),repr(match[0].decode(errors='replace')))
if a.xref:
    targets = {base+x for x in a.xref}
    for name, addr, n, offset, _, _ in sections:
        if name != '__text': continue
        pages = {}
        for off in range(offset, offset+n, 4):
            w = u32(off)
            pc = addr+off-offset
            if w & 0x9f000000 == 0x90000000:
                imm = ((w >> 5 & 0x7ffff) << 2) | (w >> 29 & 3)
                if imm & (1 << 20): imm -= 1 << 21
                pages[w & 31] = ((pc & ~4095) + imm*4096, pc)
            if w & 0xffc00000 == 0x91000000:
                rn = w >> 5 & 31
                if rn in pages and pc-pages[rn][1] <= 48:
                    target = pages[rn][0] + (w >> 10 & 4095)
                    if target in targets:
                        print('XREF',hex(pc-base),'->',hex(target-base))
                        a.offset.append(pc-base)
            if w & 0x7c000000 == 0x14000000:
                imm = w & 0x3ffffff
                if imm & (1 << 25): imm -= 1 << 26
                target = pc+imm*4
                if target in targets:
                    print('CALL/BRANCH',hex(pc-base),'->',hex(target-base))
                    a.offset.append(pc-base)
if a.offset:
    from capstone import Cs, CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN
    md = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)
    for offset in a.offset:
        pc = base + offset
        index = bisect.bisect_right(starts, pc)-1
        begin = starts[index] if index >= 0 else pc-64
        end = starts[index+1] if index+1 < len(starts) else pc+128
        print('\nOFFSET',hex(offset),'FUNCTION',hex(begin-base), 'size',end-begin, symbols.get(begin,''))
        lo, hi = (begin, end) if a.full else (max(begin,pc-80), min(end,pc+100))
        pages = {}
        for ins in md.disasm(b[lo-base:hi-base],lo):
            annotation = ''
            if ins.mnemonic in ('b','bl'):
                dest = int(ins.op_str.lstrip('#'),16)
                annotation = symbols.get(dest,'')
            if ins.mnemonic == 'adrp':
                reg, immediate = ins.op_str.split(', ')
                pages[reg] = int(immediate.lstrip('#'),16)
            if ins.mnemonic == 'add':
                parts = ins.op_str.split(', ')
                if len(parts) == 3 and parts[1] in pages and parts[2].startswith('#'):
                    address = pages[parts[1]] + int(parts[2][1:],0)
                    at = address-base
                    if 0 <= at < len(b):
                        raw = b[at:b.find(b'\0',at,at+400)]
                        if raw and all(c in (9,10,13) or 32 <= c < 127 for c in raw): annotation = repr(raw.decode())
            print(hex(ins.address-base), ins.mnemonic, ins.op_str, annotation)
