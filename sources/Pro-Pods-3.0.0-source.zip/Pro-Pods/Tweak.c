/* Pro-Pods 3.0.0: continuous guarded BTStack heap workaround, not an ID mapping fix.
 * Native malloc-zone ownership and free APIs are retained. No raw object writes. */
#include <stdint.h>
#include <stdbool.h>
#include <stdatomic.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/sysctl.h>
#include <mach-o/dyld.h>
#include <mach-o/loader.h>
#include <mach/mach.h>
#include <mach/vm_prot.h>
#include <malloc/malloc.h>
#include <CommonCrypto/CommonDigest.h>
#include <substrate.h>
#include <notify.h>
#include <dispatch/dispatch.h>
#include "VerifiedProfile.h"
#include "HeapProfile.h"
#include "Runtime.h"

/* Disassembly of this exact allocator routes requests above 0x3c00 through
 * its large allocation path. 0x4000 avoids that tiny/small free-list machinery.
 * MALLOC_ADD_GUARD_PAGES is bit 0 in Apple's libmalloc-166.200.60/src/base.h.
 * This changes timing/layout and increases memory use; it is diagnostic only. */
#define PP_GUARD_MIN 0x4000u
#define PP_RSS_LIMIT (UINT64_C(96)*1024*1024)
static atomic_bool ready,active,zone_created;
static atomic_uint_fast64_t calls,zero_calls,promoted,rss,request_nonce;
static _Atomic(const char *) gate="initializing";
static malloc_zone_t **zone_slot;
static uintptr_t create_return;
static malloc_zone_t *(*create_original)(vm_size_t,unsigned);
static void *(*alloc_original)(malloc_zone_t *,size_t);
static void *(*calloc_original)(malloc_zone_t *,size_t,size_t);
static dispatch_queue_t queue;
static dispatch_source_t timer;
static int config_token,status_token;
static time_t started;

static bool scope(malloc_zone_t *zone) {
    return atomic_load(&ready) && atomic_load(&active) && atomic_load(&zone_created) && zone && zone_slot && zone==*zone_slot;
}
static void *allocate(malloc_zone_t *zone,size_t size) {
    if(scope(zone)) {
        atomic_fetch_add(&calls,1);
        if(size<PP_GUARD_MIN){atomic_fetch_add(&promoted,1);size=PP_GUARD_MIN;}
    }
    return alloc_original ? alloc_original(zone,size) : zone->malloc(zone,size);
}
static void *zero_allocate(malloc_zone_t *zone,size_t count,size_t size) {
    if(scope(zone)) {
        atomic_fetch_add(&zero_calls,1);
        if((!count || size<=SIZE_MAX/count) && count*size<PP_GUARD_MIN) {
            atomic_fetch_add(&promoted,1);count=1;size=PP_GUARD_MIN;
        }
    }
    return calloc_original ? calloc_original(zone,count,size) : zone->calloc(zone,count,size);
}
static malloc_zone_t *create_zone(vm_size_t size,unsigned flags) {
    bool scoped=atomic_load(&ready) && atomic_load(&active) && (uintptr_t)__builtin_return_address(0)==create_return;
    malloc_zone_t *zone=create_original(size,scoped ? flags|1u : flags);
    if(scoped && zone){atomic_store(&zone_created,true);gate="guarded BTStack zone created; continuous mode";PPLog("BTStack native zone created with guard-page flag; ID mapping is not used");}
    return zone;
}
static void number(CFMutableDictionaryRef d,CFStringRef key,int64_t value) {
    CFNumberRef n=CFNumberCreate(NULL,kCFNumberSInt64Type,&value);if(n){CFDictionarySetValue(d,key,n);CFRelease(n);}
}
static void snapshot(void) {
    CFMutableDictionaryRef d=CFDictionaryCreateMutable(NULL,0,&kCFTypeDictionaryKeyCallBacks,&kCFTypeDictionaryValueCallBacks);if(!d)return;
    CFDictionarySetValue(d,CFSTR("Version"),CFSTR("3.0.0"));
    CFDictionarySetValue(d,CFSTR("Mode"),CFSTR("Continuous guarded-heap workaround; 96 MiB memory cutoff"));
    CFStringRef state=CFStringCreateWithCString(NULL,atomic_load(&gate),kCFStringEncodingUTF8);
    if(state){CFDictionarySetValue(d,CFSTR("HookState"),state);CFRelease(state);}
    number(d,CFSTR("PID"),getpid());number(d,CFSTR("Started"),started);number(d,CFSTR("Updated"),time(NULL));
    number(d,CFSTR("RequestNonce"),atomic_load(&request_nonce));
    number(d,CFSTR("AllocationCalls"),atomic_load(&calls));number(d,CFSTR("ZeroAllocationCalls"),atomic_load(&zero_calls));
    number(d,CFSTR("PromotedAllocations"),atomic_load(&promoted));number(d,CFSTR("ResidentBytes"),atomic_load(&rss));
    CFDictionarySetValue(d,CFSTR("GuardZoneCreated"),atomic_load(&zone_created)?kCFBooleanTrue:kCFBooleanFalse);
    CFDictionarySetValue(d,CFSTR("TrialActive"),atomic_load(&active)?kCFBooleanTrue:kCFBooleanFalse);
    CFDictionarySetValue(d,CFSTR("WorkaroundActive"),atomic_load(&active)?kCFBooleanTrue:kCFBooleanFalse);
    CFDataRef data=CFPropertyListCreateData(NULL,d,kCFPropertyListXMLFormat_v1_0,0,NULL);CFRelease(d);if(!data)return;
    char path[]=PP_STATUS ".XXXXXX";int fd=mkstemp(path);
    if(fd>=0) {
        ssize_t n=write(fd,CFDataGetBytePtr(data),(size_t)CFDataGetLength(data));
        if(n==CFDataGetLength(data) && !fchmod(fd,0644) && !fsync(fd)){close(fd);if(rename(path,PP_STATUS))unlink(path);}
        else {close(fd);unlink(path);}
    }
    CFRelease(data);
}
static bool matching_malloc(void) {
    for(uint32_t i=0;i<_dyld_image_count();i++) {
        const char *name=_dyld_get_image_name(i);if(!name || !strstr(name,"/libsystem_malloc.dylib"))continue;
        const struct mach_header_64 *h=(const void *)_dyld_get_image_header(i);
        if(!h || h->magic!=MH_MAGIC_64 || h->sizeofcmds>65536)return false;
        const uint8_t *p=(const void *)(h+1),*end=p+h->sizeofcmds;
        for(uint32_t j=0;j<h->ncmds;j++) {
            if((size_t)(end-p)<sizeof(struct load_command))return false;
            const struct load_command *c=(const void *)p;if(c->cmdsize<sizeof(*c) || c->cmdsize>(size_t)(end-p))return false;
            if(c->cmd==LC_UUID && c->cmdsize==sizeof(struct uuid_command)) {
                if(memcmp(((const struct uuid_command *)c)->uuid,PP_MALLOC_UUID,16))return false;
                const uint8_t *alloc=(const uint8_t *)h+PP_PUBLIC_ALLOC_OFFSET;
                const uint8_t *zero=(const uint8_t *)h+PP_PUBLIC_CALLOC_OFFSET;
                const uint8_t *create=(const uint8_t *)h+PP_PUBLIC_CREATE_OFFSET;
                if((void *)alloc!=(void *)malloc_zone_malloc || (void *)zero!=(void *)malloc_zone_calloc || (void *)create!=(void *)malloc_create_zone)return false;
                uint8_t digest[CC_SHA256_DIGEST_LENGTH];
                CC_SHA256(alloc,PP_PUBLIC_ALLOC_SIZE,digest);if(memcmp(digest,PP_PUBLIC_ALLOC_HASH,32))return false;
                CC_SHA256(zero,PP_PUBLIC_CALLOC_SIZE,digest);if(memcmp(digest,PP_PUBLIC_CALLOC_HASH,32))return false;
                CC_SHA256(create,PP_PUBLIC_CREATE_SIZE,digest);return !memcmp(digest,PP_PUBLIC_CREATE_HASH,32);
            }
            p+=c->cmdsize;
        }
    }
    return false;
}
static bool slot_is_writable(const struct mach_header_64 *h) {
    const uint8_t *p=(const void *)(h+1);
    for(uint32_t i=0;i<h->ncmds;i++) {
        const struct load_command *c=(const void *)p;
        if(c->cmd==LC_SEGMENT_64 && c->cmdsize>=sizeof(struct segment_command_64)) {
            const struct segment_command_64 *seg=(const void *)c;
            uint64_t target=PP_TEXT_VMADDR+PP_ZONE_OFFSET;
            if(target>=seg->vmaddr && target-seg->vmaddr<=seg->vmsize && sizeof(void *)<=seg->vmsize-(target-seg->vmaddr) && (seg->initprot&VM_PROT_WRITE))return true;
        }
        p+=c->cmdsize;
    }
    return false;
}
static const uint8_t *verified_function(const struct mach_header_64 *header,
                                        uint32_t offset, uint32_t size,
                                        const uint8_t expected[32]) {
    if (!header || header->magic != MH_MAGIC_64 || header->cputype != CPU_TYPE_ARM64 ||
        header->cpusubtype != 0 || header->filetype != MH_EXECUTE ||
        header->ncmds > 1024 || header->sizeofcmds > 1024 * 1024) return NULL;
    const uint8_t *cursor = (const uint8_t *)(header + 1);
    const uint8_t *end = cursor + header->sizeofcmds;
    bool uuid_ok = false, text_ok = false;
    for (uint32_t i = 0; i < header->ncmds; ++i) {
        if ((size_t)(end - cursor) < sizeof(struct load_command)) return NULL;
        const struct load_command *command = (const void *)cursor;
        if (command->cmdsize < sizeof(*command) || command->cmdsize > (size_t)(end - cursor)) return NULL;
        if (command->cmd == LC_UUID && command->cmdsize == sizeof(struct uuid_command)) {
            const struct uuid_command *uuid = (const void *)cursor;
            uuid_ok = memcmp(uuid->uuid, PP_UUID, sizeof(PP_UUID)) == 0;
        }
        if (command->cmd == LC_SEGMENT_64 && command->cmdsize >= sizeof(struct segment_command_64)) {
            const struct segment_command_64 *segment = (const void *)cursor;
            if (segment->nsects > (command->cmdsize - sizeof(*segment)) / sizeof(struct section_64)) return NULL;
            if (memcmp(segment->segname, "__TEXT\0", 7) == 0 &&
                segment->vmaddr == PP_TEXT_VMADDR && segment->fileoff == 0 &&
                segment->filesize >= offset + size && segment->vmsize >= offset + size &&
                (segment->initprot & VM_PROT_EXECUTE)) {
                const struct section_64 *sections = (const void *)(segment + 1);
                for (uint32_t j = 0; j < segment->nsects; ++j) {
                    const struct section_64 *s = &sections[j];
                    if (memcmp(s->sectname, "__text\0", 7) != 0 || s->offset > offset) continue;
                    uint64_t relative = offset - s->offset;
                    if (s->addr == PP_TEXT_VMADDR + s->offset && relative <= s->size &&
                        size <= s->size - relative) text_ok = true;
                }
            }
        }
        cursor += command->cmdsize;
    }
    if (!uuid_ok || !text_ok) return NULL;
    const uint8_t *target = (const uint8_t *)header + offset;
    uint8_t digest[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256(target, size, digest);
    return memcmp(digest, expected, sizeof(digest)) == 0 ? target : NULL;
}



__attribute__((constructor)) static void initialize(void) {
    char path[512]={0};uint32_t size=sizeof(path);
    if(_NSGetExecutablePath(path,&size) || strcmp(path,"/usr/sbin/bluetoothd"))return;
    started=time(NULL);
    queue=dispatch_queue_create("com.propods.guard-diagnostic",DISPATCH_QUEUE_SERIAL);
    char os[32]={0},machine[32]={0};size_t length=sizeof(os)-1;
    const struct mach_header_64 *h=(const void *)_dyld_get_image_header(0);
    if(sysctlbyname("kern.osproductversion",os,&length,NULL,0) || strcmp(os,"12.5.8"))gate="unsupported OS; no hooks";
    else if((length=sizeof(machine)-1,sysctlbyname("hw.machine",machine,&length,NULL,0)) || strcmp(machine,"iPod7,1"))gate="unsupported device; no hooks";
    else if(!(PPLoadSettings()&PP_ENABLED))gate="disabled by preferences/recovery marker; no hooks";
    else {
        const uint8_t *init=verified_function(h,PP_INIT_OFFSET,PP_INIT_SIZE,PP_INIT_HASH);
        const uint8_t *alloc=verified_function(h,PP_ALLOC_OFFSET,PP_ALLOC_SIZE,PP_ALLOC_HASH);
        const uint8_t *zero=verified_function(h,PP_CALLOC_OFFSET,PP_CALLOC_SIZE,PP_CALLOC_HASH);
        if(!init || !alloc || !zero || !matching_malloc() || !slot_is_writable(h))gate="image/UUID/hash/segment mismatch; no hooks";
        else {
            zone_slot=(void *)((uintptr_t)h+PP_ZONE_OFFSET);create_return=(uintptr_t)h+PP_INIT_OFFSET+0x34;
            if(*zone_slot)gate="BTStack zone already exists; no hooks";
            else {
                MSHookFunction((void *)malloc_zone_malloc,(void *)allocate,(void **)&alloc_original);
                MSHookFunction((void *)malloc_zone_calloc,(void *)zero_allocate,(void **)&calloc_original);
                MSHookFunction((void *)malloc_create_zone,(void *)create_zone,(void **)&create_original);
                bool ok=alloc_original && calloc_original && create_original;
                atomic_store(&ready,ok);atomic_store(&active,ok);
                gate=ok ? "verified hooks installed; waiting for BTStack zone creation" : "hook setup incomplete; promotion disabled";
            }
        }
    }
    PPLog("continuous guarded-heap workaround starting; no time cutoff; 96 MiB RSS safeguard; no ID mapping");PPLog(atomic_load(&gate));snapshot();
    notify_register_dispatch(PP_CHANGED,&config_token,queue,^(int token){
        (void)token;if(!(PPLoadSettings()&PP_ENABLED)){atomic_store(&active,false);gate="workaround disabled; restart bluetoothd to unload hooks";}snapshot();
    });
    notify_register_dispatch(PP_REQUEST,&status_token,queue,^(int token){
        uint64_t nonce=0;if(notify_get_state(token,&nonce)==NOTIFY_STATUS_OK)atomic_store(&request_nonce,nonce);snapshot();
    });
    timer=dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,0,0,queue);
    dispatch_source_set_timer(timer,dispatch_time(DISPATCH_TIME_NOW,2*NSEC_PER_SEC),2*NSEC_PER_SEC,NSEC_PER_SEC/4);
    dispatch_source_set_event_handler(timer,^{
        mach_task_basic_info_data_t info;mach_msg_type_number_t count=MACH_TASK_BASIC_INFO_COUNT;
        if(task_info(mach_task_self(),MACH_TASK_BASIC_INFO,(task_info_t)&info,&count)==KERN_SUCCESS)atomic_store(&rss,info.resident_size);
        if(atomic_load(&active) && atomic_load(&rss)>PP_RSS_LIMIT) {
            atomic_store(&active,false);gate="96 MiB RSS limit exceeded; promotion disabled";PPLog(atomic_load(&gate));
        }
        snapshot();
    });dispatch_resume(timer);
}
