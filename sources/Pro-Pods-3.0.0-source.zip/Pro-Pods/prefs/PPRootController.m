#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <notify.h>
@interface PPRootController : PSListController
@property(nonatomic) NSInteger previousPID;
@property(nonatomic) uint64_t requestNonce;
@end
@implementation PPRootController
- (NSMutableArray *)specifiers {
    if(_specifiers)return _specifiers;
    NSMutableArray *items=[NSMutableArray array];
    PSSpecifier *group=[PSSpecifier groupSpecifierWithName:@"Guarded Heap Diagnostic"];
    [group setProperty:@"Version 3 keeps the guarded BTStack heap workaround active without a time limit. Long-term reliability remains under evaluation. It changes memory allocation layout and can increase memory use. Device-ID and feature-version mapping are not used. Promotion stops above 96 MiB RSS. Restart bluetoothd to unload it." forKey:@"footerText"];[items addObject:group];
    for(NSString *name in @[@"Show Runtime Status",@"Copy Diagnostic Report",@"Pairing & Recovery"]) {
        PSSpecifier *s=[PSSpecifier preferenceSpecifierNamed:name target:self set:NULL get:NULL detail:Nil cell:PSButtonCell edit:Nil];
        s.buttonAction=[name hasPrefix:@"Show"] ? @selector(status) : ([name hasPrefix:@"Copy"] ? @selector(copyReport) : @selector(help));[items addObject:s];
    }
    _specifiers=items;return _specifiers;
}
- (id)value:(PSSpecifier *)s {
    CFPreferencesAppSynchronize(CFSTR("com.propods.tweak"));
    id value=CFBridgingRelease(CFPreferencesCopyAppValue((__bridge CFStringRef)[s propertyForKey:@"key"],CFSTR("com.propods.tweak")));
    if([value isKindOfClass:NSNumber.class])return value;
    return @(![@[@"legacyPro",@"max2",@"diagnostics"] containsObject:[s propertyForKey:@"key"]]);
}
- (void)setValue:(id)value specifier:(PSSpecifier *)s {
    CFPreferencesSetAppValue((__bridge CFStringRef)[s propertyForKey:@"key"],[value boolValue] ? kCFBooleanTrue : kCFBooleanFalse,CFSTR("com.propods.tweak"));
    if(CFPreferencesAppSynchronize(CFSTR("com.propods.tweak")))notify_post("com.propods.tweak.changed");
    else [self alert:@"Not saved" message:@"Could not save preferences. Reopen Settings and try again."];
}
- (void)alert:(NSString *)title message:(NSString *)message {
    UIAlertController *a=[UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [a addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];[self presentViewController:a animated:YES completion:nil];
}
- (NSString *)report {
    NSDictionary *d=[NSDictionary dictionaryWithContentsOfFile:@"/var/tmp/pro-pods-status.plist"];
    if(!d)return @"No readable daemon status. A restart and re-jailbreak is required after first installation. Respring alone does not reload bluetoothd. Verify tweak injection if status stays unavailable.";
    if(!self.requestNonce || [d[@"RequestNonce"] unsignedLongLongValue]!=self.requestNonce)
        return @"No fresh daemon response. The stored snapshot may be stale. Retry, then check injection or restart and re-jailbreak. A saved status file alone does not mean the tweak is running.";
    NSInteger pid=[d[@"PID"] integerValue];
    BOOL restarted=self.previousPID && self.previousPID!=pid;self.previousPID=pid;
    return [NSString stringWithFormat:@"Pro-Pods %@\n%@\n%@\nProcess: %ld\nTrial active: %@\nGuard zone created: %@\nAllocation calls / zeroed calls: %@ / %@\nPromoted allocations: %@\nResident bytes: %@\n%@\nCounts do not prove a stable connection. A guard-page crash can expose the original invalid access; share the new bluetoothd report.",d[@"Version"],d[@"HookState"],d[@"Mode"],(long)pid,d[@"TrialActive"],d[@"GuardZoneCreated"],d[@"AllocationCalls"],d[@"ZeroAllocationCalls"],d[@"PromotedAllocations"],d[@"ResidentBytes"],restarted ? @"Daemon restarted since the prior check." : @""];
}
- (void)requestStatus {
    int token;self.requestNonce=(((uint64_t)(arc4random()&0x7fffffff))<<32)|arc4random()|1;
    if(notify_register_check("com.propods.tweak.status-request",&token)!=NOTIFY_STATUS_OK){self.requestNonce=0;return;}
    notify_set_state(token,self.requestNonce);notify_post("com.propods.tweak.status-request");notify_cancel(token);
}
- (void)status {
    [self requestStatus];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,500*NSEC_PER_MSEC),dispatch_get_main_queue(),^{[self alert:@"Runtime Status" message:[self report]];});
}
- (void)copyReport {
    [self requestStatus];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,500*NSEC_PER_MSEC),dispatch_get_main_queue(),^{
        NSString *log=[NSString stringWithContentsOfFile:@"/var/tmp/pro-pods-status.log" encoding:NSUTF8StringEncoding error:nil] ?: @"Log unavailable";
        if(log.length>65000)log=[log substringFromIndex:log.length-65000];
        UIPasteboard.generalPasteboard.string=[[self report] stringByAppendingFormat:@"\n\n%@",log];
        [self alert:@"Copied" message:@"Diagnostic report copied. It contains runtime status, numeric product IDs and process counts, not audio, pairing keys or Bluetooth addresses."];
    });
}
- (void)help {
    [self alert:@"Guarded Heap Diagnostic" message:@"This workaround has user-reported playback and reconnect success; it is not guaranteed on every device. It uses a guarded native BTStack malloc zone and routes small allocations through the large-allocation path. Native zone ownership and frees are retained. No pairing records, IDs, headphone firmware or audio data are changed.\n\nA fresh bluetoothd process is required after installation. There is no time cutoff; the 96 MiB memory safeguard remains. If Bluetooth becomes unstable, uninstall Pro-Pods and restart/re-jailbreak, or use the root disable marker then restart bluetoothd."];
}
@end
