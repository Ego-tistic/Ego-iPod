#include "Runtime.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <notify.h>
#include <stdlib.h>
static void usage(void){puts("pro-podsctl status | enable | disable\nContinuous guarded-heap workaround: no ID mapping; 96 MiB RSS cutoff. Restart and re-jailbreak after installation to unload old hooks.");}
int main(int argc,char **argv) {
    if(argc!=2){usage();return 2;}
    if(!strcmp(argv[1],"status")) {
        int token;uint64_t nonce=(((uint64_t)(arc4random()&0x7fffffff))<<32)|arc4random()|1;
        if(notify_register_check(PP_REQUEST,&token)!=NOTIFY_STATUS_OK){puts("Status notification unavailable");return 1;}
        notify_set_state(token,nonce);notify_post(PP_REQUEST);usleep(500000);notify_cancel(token);
        CFDictionaryRef d=PPReadDictionary(PP_STATUS);
        if(!d){puts("No readable daemon status. Restart and re-jailbreak after installation; verify tweak injection.");return 1;}
        int64_t received=0;CFTypeRef n=CFDictionaryGetValue(d,CFSTR("RequestNonce"));
        if(n && CFGetTypeID(n)==CFNumberGetTypeID())CFNumberGetValue(n,kCFNumberSInt64Type,&received);
        if((uint64_t)received!=nonce){CFRelease(d);puts("No fresh daemon response. Stored status may be stale. Retry; check injection and restart/re-jailbreak if needed.");return 1;}
        CFDataRef xml=CFPropertyListCreateData(NULL,d,kCFPropertyListXMLFormat_v1_0,0,NULL);CFRelease(d);
        if(xml){fwrite(CFDataGetBytePtr(xml),1,CFDataGetLength(xml),stdout);CFRelease(xml);}
        puts("A getter mapping is NOT proof of pairing/audio. Compare PID/Started between tests to detect a process restart; crash reports are needed to establish its cause.");return 0;
    }
    if(strcmp(argv[1],"enable") && strcmp(argv[1],"disable")){usage();return 2;}
    if(geteuid()!=0){puts("This diagnostic command requires root. Use the Settings switch for ordinary enable/disable.");return 1;}
    if(!strcmp(argv[1],"disable")) {
        int fd=open(PP_DISABLED,O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW,0644);
        if(fd<0 && access(PP_DISABLED,F_OK)!=0){perror("disable");return 1;}if(fd>=0)close(fd);
    } else {
        if(unlink(PP_DISABLED) && access(PP_DISABLED,F_OK)==0){perror("enable");return 1;}
        (void)unlink("/var/mobile/Library/Preferences/com.propods.disabled");
    }
    notify_post(PP_CHANGED);puts("Override updated. Disable stops allocation promotion; restart bluetoothd to unload diagnostic hooks. Enable takes effect on a fresh daemon start. No pairing data was deleted.");return 0;
}
