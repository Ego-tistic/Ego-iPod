# Pro-Pods 3.0.0

Rootful iPod touch 6 (iPod7,1), iOS 12.5.8 only. Adapted from PodsGrant by
Ruphane / LNSSPsd; see LICENSE. User reported playback, repeated reconnects
and restarts with beta4. Version 3 retains that allocation behavior and removes
only the elapsed-time cutoff. No new device IDs or hook targets are added.

The 96 MiB process RSS cutoff, manual disable, exact daemon/library checks,
and device/OS checks remain. Exceeding the memory limit stops promotion but
does not unload hooks or remove guard flags from the existing zone. Restart
bluetoothd to unload hooks. Long-term reliability is not established.

Install through Zebra, then restart Bluetooth or reboot and re-jailbreak to
load the new binary. Installation does not automatically restart Bluetooth.
If beta4 is currently playing, upgrade when ready to interrupt playback.
Check `pro-podsctl status`; version must be 3.0.0 and WorkaroundActive true.
Existing disable markers remain respected. `pro-podsctl enable` takes effect
on a fresh daemon start. `pro-podsctl disable` plus a daemon restart disables
the workaround. Beta4 and the beta2 recovery package remain available.

Build with Theos, iOS 12.4 SDK and arm64 rootful target: `make package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME=`.
Run `python3 tools/verify_package.py path/to/package.deb` after building.
